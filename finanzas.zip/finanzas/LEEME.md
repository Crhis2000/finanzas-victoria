# Mis finanzas (versión para un usuario nuevo)

Empieza vacía: la persona llena todo. Al entrar ve una lista de **primeros pasos** (ingresos, gastos fijos, deudas, propiedades, metas y Face ID) que se quita sola al completarla.

Diseño estilo app de banco: menú abajo (Inicio, Mes, Inversiones, Deudas, Más).
- Inicio: patrimonio (propiedades + ahorros − deudas) con su gráfica mes a mes, el mes, próximos pagos, metas.
- Inversiones: cada propiedad con costo, valor actual, tu parte, alquiler, rendimiento, gastos/servicios
  y su historial de contratos (inquilino, contacto, fechas, depósito recibido y a devolver, PDF del contrato).
- Calendario: lo que toca pagar y cobrar en los próximos 60 días.
- Fijos: mensuales o cada 2, 3, 4, 6 o 12 meses.

Portal privado para gastos personales, ingresos y propiedades.

- Mes: lo que te entró, lo que gastaste y lo que te queda. Anotas gastos/ingresos y confirmas los fijos.
- Fijos: gastos e ingresos que se repiten (día del mes; si son dos al mes, "5, 20").
- Deudas: saldo de cada deuda; cada abono baja el saldo solo y cuenta como gasto del mes.
- Propiedades: alquiler, tu parte (%), día de pago y contrato. En tus totales solo cuenta tu parte.
- Anotar rápido: monto + toca la categoría. Gasto o ingreso extra. Foto del recibo opcional.
- Límites (Ajustes): tope al mes por categoría, semáforo verde/amarillo/rojo.
- Ahorros: impuestos (apartar % de cada ingreso, pagos estimados al IRS) y fondo de emergencia.
- Cierre de mes: lo que sobró, a qué deuda mandarlo o guardarlo.
- Plan de deudas: interés y mínimo de cada una, cuánto pagas al mes, orden y fecha en que terminas.
- Año: mes por mes y gastos por categoría. Excel y copia de seguridad.

- Ocultar montos: el ojo en Inicio (o en Ajustes) cambia todos los números por $••••. Se recuerda en ese teléfono.
- Face ID: en Ajustes → "Activar Face ID en este teléfono". Después entras con tu cara (passkey).
  Opción "Pedir Face ID al abrir la app": si pasan 5 minutos sin usarla, te la pide otra vez.

- Documentos: en cada propiedad sube la reserva, el documento de compra, registro, pagos (PDF o foto).

- Deudas: en Editar cambias "Lo que debes hoy" (lo abonado se respeta). Cada deuda tiene su historial de abonos por fecha.

- Calculadora (Deudas): escoges deudas y cuánto abonas al mes; te dice cuándo sales, intereses y cuánto necesitas para salir en X meses.

- Si cierras la app o la pestaña y la vuelves a abrir, pide Face ID (o la clave si ese teléfono no tiene Face ID).

- Consejo (Deudas → Calculadora): escoges tu prioridad (menos intereses, resultados rápido, bajar el mensual o una en específico) y te dice a cuál meterle primero.
- Pagos agendados (Deudas): fecha + cuenta + monto, opción cada mes. Sale en Inicio y Calendario; botón para meterlo al calendario del teléfono con alarma; "Pagado" anota el abono solo.

- Bolsa (Más → Bolsa): anotas lo que compras o vendes en tu app de inversiones y aquí ves cuánto vale cada día, cuánto vas ganando o perdiendo, acciones que sigues con señales (cuánto bajó hoy, qué tan lejos está de su máximo del año) y noticias. Datos de Finnhub (gratis).

- Susus (Más → Susus): pegas la lista de turnos de WhatsApp; te dice cuándo cobras, cuánto has puesto, te avisa cada pago y puedes pagar la mano de otra persona descontándolo de su deuda.

- Seguros (Más → Seguros): pago mensual (se agrega a fijos), valor de rescate, acumulado y total pagado; el rescate cuenta en tu patrimonio.

## Railway
Variables: USUARIO (su usuario), CLAVE (su clave), NOMBRE (cómo saludarla, ej. María), SECRET_KEY (texto largo al azar).
Usa las mismas variables que el proyecto de Crhistopher (DB_PATH, HTTPS, etc.), pero con usuario, clave, nombre y SECRET_KEY nuevos.
Opcional: FINNHUB_KEY (o pégala en Más → Bolsa).
Volumen montado en /data (ahí vive la base de datos).
