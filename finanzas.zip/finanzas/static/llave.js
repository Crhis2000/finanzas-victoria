// Face ID / huella con passkeys (WebAuthn). El servidor guarda solo la llave pública.
(function () {
  function aB64u(buf) {
    var b = new Uint8Array(buf), s = "";
    for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function deB64u(s) {
    s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
    var t = atob(s), b = new Uint8Array(t.length);
    for (var i = 0; i < t.length; i++) b[i] = t.charCodeAt(i);
    return b.buffer;
  }
  function csrf() {
    var m = document.querySelector('meta[name="csrf"]'); return m ? m.content : "";
  }
  async function enviar(url, extra) {
    var f = new FormData(); f.append("csrf", csrf());
    for (var k in (extra || {})) f.append(k, extra[k]);
    var r = await fetch(url, { method: "POST", body: f, credentials: "same-origin" });
    var d = {}; try { d = await r.json(); } catch (e) {}
    if (!r.ok) throw new Error(d.error || "Algo falló. Inténtalo otra vez.");
    return d;
  }
  function mensajeError(e) {
    if (e && e.name === "NotAllowedError") return "Se canceló o no se reconoció. Inténtalo otra vez.";
    if (e && e.name === "InvalidStateError") return "Este teléfono ya tiene Face ID activado.";
    return (e && e.message) || "Algo falló. Inténtalo otra vez.";
  }

  window.faceIdDisponible = async function () {
    try {
      return !!(window.PublicKeyCredential && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable());
    } catch (e) { return false; }
  };

  window.activarFaceId = async function (nombre) {
    try {
      var o = await enviar("/llave/registro/opciones");
      o.challenge = deB64u(o.challenge);
      o.user.id = deB64u(o.user.id);
      o.excludeCredentials = (o.excludeCredentials || []).map(function (c) { return { type: c.type, id: deB64u(c.id) }; });
      var cred = await navigator.credentials.create({ publicKey: o });
      var r = cred.response;
      if (!r.getPublicKey || !r.getAuthenticatorData) throw new Error("Este navegador es muy viejo para Face ID. Actualiza el teléfono.");
      await enviar("/llave/registro", {
        nombre: nombre || "Mi teléfono",
        credencial: JSON.stringify({
          id: cred.id, clientDataJSON: aB64u(r.clientDataJSON), authenticatorData: aB64u(r.getAuthenticatorData()),
          publicKey: aB64u(r.getPublicKey()), alg: r.getPublicKeyAlgorithm()
        })
      });
      return null;
    } catch (e) { return mensajeError(e); }
  };

  window.entrarFaceId = async function () {
    try {
      var o = await enviar("/llave/entrar/opciones");
      o.challenge = deB64u(o.challenge);
      o.allowCredentials = o.allowCredentials.map(function (c) { return { type: c.type, id: deB64u(c.id), transports: c.transports }; });
      var cred = await navigator.credentials.get({ publicKey: o });
      var r = cred.response;
      var d = await enviar("/llave/entrar", {
        credencial: JSON.stringify({
          id: cred.id, clientDataJSON: aB64u(r.clientDataJSON),
          authenticatorData: aB64u(r.authenticatorData), signature: aB64u(r.signature)
        })
      });
      try { sessionStorage.setItem("abierta", "1"); } catch (e) {}
      location.href = d.ir || "/resumen";
      return null;
    } catch (e) { return mensajeError(e); }
  };
})();
