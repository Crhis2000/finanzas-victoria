"""Mis finanzas - versión para un usuario nuevo (empieza vacía; la persona llena todo)."""
import os, sqlite3, secrets, threading, tempfile, time, re, json, io
import urllib.request
from datetime import date, datetime, timedelta
from functools import wraps
from flask import (Flask, render_template, request, redirect, url_for, session, flash, g, abort, send_file)

DB = os.environ.get("DB_PATH", "finanzas.db")
USUARIO = os.environ.get("USUARIO", "usuario").lower()
NOMBRE = os.environ.get("NOMBRE", "").strip() or USUARIO.capitalize()
CON_ENLACE = os.environ.get("CON_ENLACE") == "1"  # enlace con el portal de Talavera: apagado
CLAVE = os.environ.get("CLAVE")  # obligatoria en producción
RECIBOS = os.path.join(os.path.dirname(os.path.abspath(DB)), "recibos")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("HTTPS", "0") == "1",
                  PERMANENT_SESSION_LIFETIME=timedelta(days=30), MAX_CONTENT_LENGTH=25 * 1024 * 1024)

CAT_GASTO = ["Comida", "Gasolina", "Salidas y entretenimiento", "Carro", "Cuidado personal", "Casa / Renta",
             "Teléfono e Internet", "Seguros", "Salud", "Suscripciones", "Familia / Envíos", "Compras",
             "Tarjetas y deudas", "Impuestos", "Propiedades", "Préstamos que hice", "Susu", "Otros"]
CAT_DEUDA = ["Tarjeta de crédito", "Préstamo personal", "Préstamo de banco", "Impuestos", "Otros"]
CAT_INGRESO = ["Sueldo / Trabajo", "Intereses de préstamos", "Alquileres", "Trabajos extra", "Ventas / Reventa", "Me pagaron lo que me debían", "Susu", "Otros ingresos"]
CAT_EXTRA = ["Sueldo / Trabajo", "Trabajos extra", "Ventas / Reventa", "Otros ingresos"]  # para anotar rápido
ICONOS = {"Comida": "🍔", "Gasolina": "⛽", "Salidas y entretenimiento": "🎉", "Carro": "🚗",
          "Cuidado personal": "💈", "Casa / Renta": "🏠", "Teléfono e Internet": "📱", "Seguros": "🛡️",
          "Salud": "💊", "Suscripciones": "🔁", "Familia / Envíos": "👪", "Compras": "🛍️", "Otros": "•",
          "Tarjetas y deudas": "💳", "Impuestos": "🏛️", "Propiedades": "🏘️",
          "Trabajos extra": "🧰", "Ventas / Reventa": "🏷️", "Otros ingresos": "➕",
          "Sueldo / Trabajo": "💼", "Intereses de préstamos": "💵", "Alquileres": "🔑", "Préstamos que hice": "🤝", "Me pagaron lo que me debían": "🤝", "Susu": "🔄"}
# pagos estimados al IRS (mes, día)
FECHAS_IRS = [(1, 15), (4, 15), (6, 15), (9, 15)]
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre",
         "octubre", "noviembre", "diciembre"]

ESQUEMA = """
CREATE TABLE IF NOT EXISTS propiedades(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, alquiler REAL DEFAULT 0, parte REAL DEFAULT 50,
  dia_pago INTEGER DEFAULT 1, inicio TEXT, fin TEXT, socio TEXT, activa INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS fijos(
  id INTEGER PRIMARY KEY, tipo TEXT NOT NULL, nombre TEXT NOT NULL, categoria TEXT, monto REAL DEFAULT 0,
  dias TEXT DEFAULT '1', propiedad_id INTEGER, activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS movimientos(
  id INTEGER PRIMARY KEY, tipo TEXT NOT NULL, fecha TEXT NOT NULL, monto REAL NOT NULL, categoria TEXT,
  nota TEXT, fijo_id INTEGER, ocurrencia TEXT, propiedad_id INTEGER);
CREATE TABLE IF NOT EXISTS deudas(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, categoria TEXT, saldo_inicial REAL DEFAULT 0,
  abonado_antes REAL DEFAULT 0, activa INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS ahorros(
  id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, tipo TEXT DEFAULT 'meta', meta REAL, activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS contratos(
  id INTEGER PRIMARY KEY, propiedad_id INTEGER NOT NULL, unidad TEXT, inquilino TEXT, telefono TEXT, correo TEXT,
  documento TEXT, inicio TEXT, fin TEXT, monto REAL DEFAULT 0, dia_pago INTEGER DEFAULT 1, deposito_meses REAL,
  deposito_recibido REAL, deposito_devolver REAL, deposito_devuelto REAL, estado TEXT DEFAULT 'activo',
  fecha_salida TEXT, notas TEXT, archivo TEXT);
CREATE TABLE IF NOT EXISTS por_cobrar(
  id INTEGER PRIMARY KEY, persona TEXT NOT NULL, concepto TEXT, monto REAL DEFAULT 0, cobrado_antes REAL DEFAULT 0,
  fecha TEXT, vence TEXT, telefono TEXT, notas TEXT, activa INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS patrimonio(mes TEXT PRIMARY KEY, total REAL, propiedades REAL, ahorros REAL, deudas REAL);
CREATE TABLE IF NOT EXISTS limites(categoria TEXT PRIMARY KEY, monto REAL NOT NULL);
CREATE TABLE IF NOT EXISTS ajustes(clave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS historial(id INTEGER PRIMARY KEY, cuando TEXT, texto TEXT);
CREATE TABLE IF NOT EXISTS polizas(
  id INTEGER PRIMARY KEY, nombre TEXT, aseguradora TEXT, tipo TEXT, prima REAL, dia_pago INTEGER, beneficio REAL,
  notas TEXT, fijo_id INTEGER, activa INTEGER DEFAULT 1, creada TEXT);
CREATE TABLE IF NOT EXISTS poliza_valores(
  id INTEGER PRIMARY KEY, poliza_id INTEGER NOT NULL, fecha TEXT, acumulado REAL, rescate REAL, pagado REAL);
CREATE TABLE IF NOT EXISTS susus(
  id INTEGER PRIMARY KEY, nombre TEXT, organizador TEXT, monto REAL, previos INTEGER DEFAULT 0, activo INTEGER DEFAULT 1, creado TEXT);
CREATE TABLE IF NOT EXISTS susu_turnos(
  id INTEGER PRIMARY KEY, susu_id INTEGER NOT NULL, fecha TEXT NOT NULL, nombre TEXT, mio INTEGER DEFAULT 0, cobrado REAL, mov_id INTEGER);
CREATE TABLE IF NOT EXISTS susu_manos(
  id INTEGER PRIMARY KEY, susu_id INTEGER NOT NULL, nombre TEXT, monto REAL, deuda_id INTEGER, desde TEXT, propia INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS susu_pagos(
  id INTEGER PRIMARY KEY, susu_id INTEGER, turno_id INTEGER, mano_id INTEGER, monto REAL, fecha TEXT, mov_id INTEGER);
CREATE TABLE IF NOT EXISTS bolsa_ops(
  id INTEGER PRIMARY KEY, simbolo TEXT NOT NULL, tipo TEXT NOT NULL, fecha TEXT NOT NULL, monto REAL NOT NULL,
  precio REAL NOT NULL, acciones REAL NOT NULL, nota TEXT);
CREATE TABLE IF NOT EXISTS bolsa_seguir(simbolo TEXT PRIMARY KEY, agregada TEXT);
CREATE TABLE IF NOT EXISTS bolsa_cache(clave TEXT PRIMARY KEY, datos TEXT, cuando REAL);
CREATE TABLE IF NOT EXISTS agenda(
  id INTEGER PRIMARY KEY, deuda_id INTEGER, nombre TEXT NOT NULL, monto REAL DEFAULT 0, fecha TEXT NOT NULL,
  nota TEXT, mensual INTEGER DEFAULT 0, estado TEXT DEFAULT 'pendiente', mov_id INTEGER, creado TEXT);
CREATE TABLE IF NOT EXISTS documentos(
  id INTEGER PRIMARY KEY, propiedad_id INTEGER NOT NULL, tipo TEXT, nombre TEXT, nota TEXT, fecha TEXT,
  archivo TEXT NOT NULL, subido TEXT);
CREATE TABLE IF NOT EXISTS llaves(
  id INTEGER PRIMARY KEY, cred_id TEXT UNIQUE NOT NULL, clave_publica BLOB NOT NULL, alg INTEGER,
  contador INTEGER DEFAULT 0, nombre TEXT, creada TEXT, usada TEXT);
"""
BLOQUEO_MIN = 5  # minutos sin usar la app antes de volver a pedir Face ID


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def cerrar(_):
    c = g.pop("db", None)
    if c: c.close()


def anotar(texto):
    try:
        db().execute("INSERT INTO historial(cuando, texto) VALUES(?,?)",
                     (datetime.now().strftime("%Y-%m-%d %H:%M"), texto[:400]))
    except Exception:
        pass


def iniciar_db():
    con = sqlite3.connect(DB)
    con.executescript(ESQUEMA)
    for tabla, col, tipo in (("movimientos", "deuda_id", "INTEGER"), ("fijos", "desde", "TEXT"),
                             ("movimientos", "ahorro_id", "INTEGER"), ("movimientos", "recibo", "TEXT"),
                             ("movimientos", "origen", "TEXT"), ("deudas", "interes", "REAL"),
                             ("deudas", "minimo", "REAL"), ("movimientos", "contrato_id", "INTEGER"), ("movimientos", "cobro_id", "INTEGER"),
                             ("patrimonio", "me_deben", "REAL"),
                             ("fijos", "cada", "INTEGER DEFAULT 1"), ("fijos", "mes_inicio", "TEXT"),
                             ("propiedades", "tipo", "TEXT"), ("propiedades", "ubicacion", "TEXT"),
                             ("propiedades", "costo", "REAL"), ("propiedades", "valor_actual", "REAL"),
                             ("propiedades", "estado", "TEXT"), ("propiedades", "notas", "TEXT"),
                             ("propiedades", "fecha_compra", "TEXT"),
                             ("fijos", "capital", "REAL"), ("fijos", "interes", "REAL"), ("fijos", "interes_periodo", "TEXT")):
        if col not in {r[1] for r in con.execute(f"PRAGMA table_info({tabla})")}:
            con.execute(f"ALTER TABLE {tabla} ADD COLUMN {col} {tipo}")
    if con.execute("PRAGMA user_version").fetchone()[0] < 4:
        # app nueva: empieza vacía, solo con los dos apartados básicos
        con.execute("INSERT OR IGNORE INTO ajustes(clave, valor) VALUES('creado', ?)", (date.today().isoformat(),))
        if con.execute("SELECT COUNT(*) FROM ahorros").fetchone()[0] == 0:
            con.execute("INSERT INTO ahorros(nombre, tipo, meta) VALUES('Impuestos (IRS)', 'impuestos', NULL)")
            con.execute("INSERT INTO ahorros(nombre, tipo, meta) VALUES('Fondo de emergencia', 'emergencia', NULL)")
        con.execute("INSERT OR IGNORE INTO ajustes(clave, valor) VALUES('pct_impuestos', '25')")
        con.execute("INSERT OR IGNORE INTO ajustes(clave, valor) VALUES('cats_impuestos', ?)",
                    (json.dumps(["Trabajos extra"]),))
        con.execute("PRAGMA user_version=4")
    con.commit(); con.close()


def ajuste(clave, valor=None, defecto=None):
    if valor is None:
        r = db().execute("SELECT valor FROM ajustes WHERE clave=?", (clave,)).fetchone()
        return r[0] if r else defecto
    db().execute("INSERT INTO ajustes(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                 (clave, str(valor)))


# ---------- seguridad ----------
def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token
INTENTOS = {}


@app.before_request
def revisar_csrf():
    if request.method == "POST" and request.form.get("csrf") != session.get("csrf"):
        abort(400)


def hay_llaves():
    return db().execute("SELECT 1 FROM llaves LIMIT 1").fetchone() is not None


def bloqueo_activo():
    return ajuste("bloqueo") == "1" and hay_llaves()


def requiere(fn):
    @wraps(fn)
    def envuelta(*a, **k):
        if not session.get("ok"):
            return redirect(url_for("entrar"))
        ahora = time.time()
        if session.get("bloqueado"):
            return redirect(url_for("bloquear"))
        if bloqueo_activo() and ahora - session.get("visto", 0) > BLOQUEO_MIN * 60:
            return redirect(url_for("bloqueo"))
        session["visto"] = ahora
        return fn(*a, **k)
    return envuelta


@app.route("/", methods=["GET", "POST"])
def entrar():
    if session.get("ok"):
        return redirect(url_for("resumen"))
    if request.method == "POST":
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        f, t = INTENTOS.get(ip, (0, 0))
        if f >= 6 and time.time() - t < 900:
            flash("Demasiados intentos. Espera 15 minutos.")
            return render_template("entrar.html")
        u, c = request.form.get("usuario", "").strip().lower(), request.form.get("clave", "")
        if CLAVE and u == USUARIO and secrets.compare_digest(c, CLAVE):
            session.clear(); session.permanent = True; session["ok"] = True; session["visto"] = time.time()
            INTENTOS.pop(ip, None)
            return redirect(url_for("resumen"))
        INTENTOS[ip] = (f + 1, t if f else time.time())
        anotar(f"Intento fallido de entrar (usuario «{u[:30]}»)"); db().commit()
        flash("Usuario o clave incorrectos.")
    return render_template("entrar.html", face_id=hay_llaves())


@app.route("/salir")
def salir():
    session.clear()
    return redirect(url_for("entrar"))


# ---------- Face ID / huella (passkeys, WebAuthn) ----------
def b64u(b):
    import base64
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def de_b64u(s):
    import base64
    s = str(s or "")
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def rp_id():
    return request.host.split(":")[0]


def origen_esperado():
    https = os.environ.get("HTTPS", "0") == "1" or request.headers.get("X-Forwarded-Proto") == "https"
    return ("https://" if https else request.scheme + "://") + request.host


def revisar_cliente(datos_cliente, tipo):
    """Revisa el clientDataJSON: tipo, reto de esta sesión y que venga de este portal."""
    reto = session.pop("wa_reto", None)
    try:
        c = json.loads(datos_cliente)
    except Exception:
        return False
    return bool(reto) and c.get("type") == tipo and secrets.compare_digest(str(c.get("challenge", "")), reto) \
        and c.get("origin") == origen_esperado()


def revisar_autenticador(auth):
    """authenticatorData: hash del dominio, usuario presente (UP) y verificado con Face ID/huella (UV)."""
    import hashlib
    if len(auth) < 37 or auth[:32] != hashlib.sha256(rp_id().encode()).digest():
        return None
    flags = auth[32]
    if not (flags & 0x01 and flags & 0x04):
        return None
    return int.from_bytes(auth[33:37], "big")


def nuevo_reto():
    r = b64u(secrets.token_bytes(32))
    session["wa_reto"] = r
    return r


def json_err(msg, code=400):
    return app.response_class(json.dumps({"error": msg}), status=code, mimetype="application/json")


def json_ok(d):
    return app.response_class(json.dumps(d), mimetype="application/json")


@app.route("/llave/registro/opciones", methods=["POST"])
@requiere
def llave_opciones_registro():
    ya = [{"type": "public-key", "id": r["cred_id"]} for r in db().execute("SELECT cred_id FROM llaves")]
    return json_ok({"challenge": nuevo_reto(), "rp": {"id": rp_id(), "name": "Mis finanzas"},
                    "user": {"id": b64u(USUARIO.encode()), "name": USUARIO, "displayName": NOMBRE},
                    "pubKeyCredParams": [{"type": "public-key", "alg": -7}, {"type": "public-key", "alg": -257}],
                    "authenticatorSelection": {"authenticatorAttachment": "platform", "userVerification": "required",
                                               "residentKey": "preferred"},
                    "excludeCredentials": ya, "attestation": "none", "timeout": 60000})


@app.route("/llave/registro", methods=["POST"])
@requiere
def llave_registro():
    from cryptography.hazmat.primitives.serialization import load_der_public_key
    try:
        d = json.loads(request.form.get("credencial", "{}"))
        datos_cliente = de_b64u(d["clientDataJSON"]); auth = de_b64u(d["authenticatorData"])
        clave_pub = de_b64u(d["publicKey"]); alg = int(d["alg"]); cred_id = d["id"]
        load_der_public_key(clave_pub)
    except Exception:
        return json_err("Este teléfono no mandó bien la llave. Actualiza el sistema e inténtalo otra vez.")
    if alg not in (-7, -257) or not revisar_cliente(datos_cliente, "webauthn.create"):
        return json_err("No se pudo verificar. Inténtalo otra vez.")
    contador = revisar_autenticador(auth)
    if contador is None:
        return json_err("Hace falta Face ID o huella para activarlo.")
    nombre = (request.form.get("nombre") or "Mi teléfono").strip()[:40]
    db().execute("INSERT OR REPLACE INTO llaves(cred_id, clave_publica, alg, contador, nombre, creada) VALUES(?,?,?,?,?,?)",
                 (cred_id, clave_pub, alg, contador, nombre, datetime.now().strftime("%Y-%m-%d %H:%M")))
    anotar(f"Activaste Face ID en «{nombre}»"); db().commit()
    flash("¡Face ID activado en este teléfono! La próxima vez entras con tu cara.")
    return json_ok({"ok": True})


@app.route("/llave/entrar/opciones", methods=["POST"])
def llave_opciones_entrar():
    llaves = [{"type": "public-key", "id": r["cred_id"], "transports": ["internal", "hybrid"]}
              for r in db().execute("SELECT cred_id FROM llaves")]
    if not llaves:
        return json_err("No hay Face ID activado. Entra con tu clave.")
    return json_ok({"challenge": nuevo_reto(), "rpId": rp_id(), "allowCredentials": llaves,
                    "userVerification": "required", "timeout": 60000})


@app.route("/llave/entrar", methods=["POST"])
def llave_entrar():
    import hashlib
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, padding
    from cryptography.hazmat.primitives.serialization import load_der_public_key
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    f, t = INTENTOS.get(ip, (0, 0))
    if f >= 6 and time.time() - t < 900:
        return json_err("Demasiados intentos. Espera 15 minutos.", 429)
    try:
        d = json.loads(request.form.get("credencial", "{}"))
        datos_cliente = de_b64u(d["clientDataJSON"]); auth = de_b64u(d["authenticatorData"])
        firma = de_b64u(d["signature"]); cred_id = d["id"]
    except Exception:
        return json_err("No se pudo leer el Face ID. Inténtalo otra vez.")
    llave = db().execute("SELECT * FROM llaves WHERE cred_id=?", (cred_id,)).fetchone()
    contador = revisar_autenticador(auth)
    ok = llave is not None and contador is not None and revisar_cliente(datos_cliente, "webauthn.get")
    if ok:
        mensaje = auth + hashlib.sha256(datos_cliente).digest()
        try:
            pub = load_der_public_key(llave["clave_publica"])
            if llave["alg"] == -257:
                pub.verify(firma, mensaje, padding.PKCS1v15(), hashes.SHA256())
            else:
                pub.verify(firma, mensaje, ec.ECDSA(hashes.SHA256()))
        except Exception:
            ok = False
    # el contador debe subir (los iPhone siempre mandan 0, eso se acepta)
    if ok and contador and llave["contador"] and contador <= llave["contador"]:
        ok = False
    if not ok:
        INTENTOS[ip] = (f + 1, t if f else time.time())
        anotar("Intento fallido de entrar con Face ID"); db().commit()
        return json_err("No se pudo verificar tu Face ID.", 403)
    db().execute("UPDATE llaves SET contador=?, usada=? WHERE id=?",
                 (contador, datetime.now().strftime("%Y-%m-%d %H:%M"), llave["id"]))
    db().commit()
    INTENTOS.pop(ip, None)
    csrf = session.get("csrf")
    session.clear(); session.permanent = True; session["ok"] = True; session["visto"] = time.time()
    if csrf: session["csrf"] = csrf
    return json_ok({"ok": True, "ir": url_for("resumen")})


@app.route("/bloqueo")
def bloqueo():
    if not session.get("ok"):
        return redirect(url_for("entrar"))
    if not hay_llaves():
        session.clear()
        return redirect(url_for("entrar"))
    if not (bloqueo_activo() or session.get("bloqueado")):
        return redirect(url_for("resumen"))
    return render_template("bloqueo.html")


@app.route("/bloquear")
def bloquear():
    """La app se volvió a abrir después de cerrarla: pide Face ID, o la clave si no hay Face ID."""
    if not session.get("ok"):
        return redirect(url_for("entrar"))
    if hay_llaves():
        session["bloqueado"] = True
        return redirect(url_for("bloqueo"))
    session.clear()
    return redirect(url_for("entrar"))


# ---------- utilidades ----------
def num(x):
    try:
        return round(float((x or "").replace(",", "").replace("$", "").strip()), 2)
    except ValueError:
        return None


def dias_de(fijo):
    return sorted({int(d) for d in re.findall(r"\d+", fijo["dias"] or "1") if 1 <= int(d) <= 31}) or [1]


def fecha_en_mes(anio, mes, dia):
    ultimo = (date(anio + (mes == 12), mes % 12 + 1, 1) - timedelta(days=1)).day
    return date(anio, mes, min(dia, ultimo))


def mes_param():
    m = request.args.get("mes") or request.form.get("mes") or date.today().strftime("%Y-%m")
    try:
        a, mm = map(int, m.split("-")); date(a, mm, 1)
        return a, mm
    except Exception:
        return date.today().year, date.today().month


def propiedades():
    return {p["id"]: p for p in db().execute("SELECT * FROM propiedades")}


def mi_monto(mov, props):
    """Lo que te toca a ti: en propiedades, solo tu parte."""
    if mov["propiedad_id"] and mov["propiedad_id"] in props:
        return mov["monto"] * (props[mov["propiedad_id"]]["parte"] or 0) / 100
    return mov["monto"]


FRECUENCIAS = {1: "Cada mes", 2: "Cada 2 meses", 3: "Cada 3 meses", 4: "Cada 4 meses", 6: "Cada 6 meses", 12: "Una vez al año"}


def ocurre_en_mes(f, anio, mes):
    cada = f["cada"] or 1
    if cada <= 1:
        return True
    ini = f["mes_inicio"] or (f["desde"] or "")[:7]
    if not re.fullmatch(r"\d{4}-\d{2}", ini or ""):
        return True
    dif = (anio * 12 + mes) - (int(ini[:4]) * 12 + int(ini[5:7]))
    return dif >= 0 and dif % cada == 0


def eventos_mes(anio, mes, desde_creado=True):
    """Lo que toca pagar o cobrar en el mes: fijos (con su frecuencia) y alquileres de cada contrato activo."""
    hoy = date.today()
    if desde_creado and date(anio, mes, 1) < creado_desde():
        return []  # meses de antes de empezar a usar el portal
    props = propiedades()
    res = []
    ym = f"{anio}-{mes:02d}"

    def estado_de(fe, hecho):
        return "hecho" if hecho else ("atrasado" if fe < hoy else ("pronto" if fe <= hoy + timedelta(days=7) else "luego"))

    for f in db().execute("SELECT * FROM fijos WHERE activo=1 AND propiedad_id IS NULL"):
        if not ocurre_en_mes(f, anio, mes):
            continue
        for d in dias_de(f):
            fe = fecha_en_mes(anio, mes, d)
            oc = fe.isoformat()
            if f["desde"] and oc < f["desde"] and (f["cada"] or 1) <= 1:
                continue  # todavía no existía este fijo
            hecho = db().execute("SELECT * FROM movimientos WHERE fijo_id=? AND ocurrencia=?", (f["id"], oc)).fetchone()
            ult = db().execute("SELECT monto FROM movimientos WHERE fijo_id=? ORDER BY fecha DESC LIMIT 1", (f["id"],)).fetchone()
            res.append({"clave": f"f{f['id']}", "nombre": f["nombre"], "tipo": f["tipo"], "fecha": fe, "ocurrencia": oc,
                        "hecho": hecho, "sugerido": hecho["monto"] if hecho else (ult[0] if ult else f["monto"]),
                        "estado": estado_de(fe, hecho), "factor": 1, "categoria": f["categoria"],
                        "frecuencia": FRECUENCIAS.get(f["cada"] or 1, f"Cada {f['cada']} meses") if (f["cada"] or 1) > 1 else ""})
    for c in db().execute("SELECT * FROM contratos WHERE estado='activo'"):
        p = props.get(c["propiedad_id"])
        if not p or not p["activa"]:
            continue
        if (c["inicio"] and ym < c["inicio"][:7]) or (c["fin"] and ym > c["fin"][:7]):
            continue
        fe = fecha_en_mes(anio, mes, c["dia_pago"] or 1)
        if c["fin"] and fe.isoformat() > c["fin"]:
            continue
        oc = fe.isoformat()
        hecho = db().execute("SELECT * FROM movimientos WHERE contrato_id=? AND ocurrencia=?", (c["id"], oc)).fetchone()
        nombre = f"Alquiler {p['nombre']}" + (f" ({c['unidad']})" if c["unidad"] else "")
        res.append({"clave": f"c{c['id']}", "nombre": nombre, "tipo": "ingreso", "fecha": fe, "ocurrencia": oc,
                    "hecho": hecho, "sugerido": hecho["monto"] if hecho else (c["monto"] or 0), "estado": estado_de(fe, hecho),
                    "factor": (p["parte"] or 0) / 100, "categoria": "Alquileres", "propiedad": p["nombre"],
                    "frecuencia": c["inquilino"] or ""})
    return res


def pendientes_mes(anio, mes):
    orden = {"atrasado": 0, "pronto": 1, "luego": 2, "hecho": 3}
    return sorted(eventos_mes(anio, mes), key=lambda x: (orden[x["estado"]], x["fecha"]))


def totales_mes(anio, mes):
    props = propiedades()
    ini, fin = date(anio, mes, 1), fecha_en_mes(anio, mes, 31)
    movs = db().execute("SELECT * FROM movimientos WHERE fecha BETWEEN ? AND ? ORDER BY fecha DESC, id DESC",
                        (ini.isoformat(), fin.isoformat())).fetchall()
    ing = sum(mi_monto(m, props) for m in movs if m["tipo"] == "ingreso")
    gas = sum(mi_monto(m, props) for m in movs if m["tipo"] == "gasto")
    porcat = {}
    for m in movs:
        if m["tipo"] == "gasto":
            porcat[m["categoria"] or "Otros"] = porcat.get(m["categoria"] or "Otros", 0) + mi_monto(m, props)
    return movs, round(ing, 2), round(gas, 2), dict(sorted(porcat.items(), key=lambda x: -x[1]))


def estado_deudas():
    res = []
    for d in db().execute("SELECT * FROM deudas WHERE activa=1 ORDER BY nombre"):
        abonos = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE deuda_id=?", (d["id"],)).fetchone()[0]
        abonado = (d["abonado_antes"] or 0) + abonos
        saldo = max(0, (d["saldo_inicial"] or 0) - abonado)
        ult = db().execute("SELECT fecha, monto FROM movimientos WHERE deuda_id=? ORDER BY fecha DESC, id DESC LIMIT 1",
                           (d["id"],)).fetchone()
        # historial: cada abono con la fecha y cuánto quedaba debiendo después
        filas = db().execute("SELECT id, fecha, monto, nota FROM movimientos WHERE deuda_id=? ORDER BY fecha, id",
                             (d["id"],)).fetchall()
        quedaba, hist = (d["saldo_inicial"] or 0) - (d["abonado_antes"] or 0), []
        for f in filas:
            quedaba -= f["monto"]
            hist.append({"id": f["id"], "fecha": f["fecha"], "monto": f["monto"], "nota": f["nota"], "quedo": max(0, quedaba)})
        hist.reverse()
        res.append({"d": d, "abonado": abonado, "saldo": saldo, "ultimo": ult, "historial": hist,
                    "pct": (abonado / d["saldo_inicial"] * 100) if d["saldo_inicial"] else 0})
    return res


def creado_desde():
    r = ajuste("creado")
    return date.fromisoformat(r).replace(day=1) if r else date(2000, 1, 1)


def cats_impuestos():
    try:
        return json.loads(ajuste("cats_impuestos", defecto="[]"))
    except ValueError:
        return []


def pct_impuestos():
    try:
        return max(0.0, min(60.0, float(ajuste("pct_impuestos", defecto="25"))))
    except ValueError:
        return 25.0


def resumen_mes(anio, mes):
    """Todo lo del mes separado: fijos vs extras, variables, abonos y lo apartado."""
    props = propiedades()
    movs, ing, gas, porcat = totales_mes(anio, mes)
    ini, fin = date(anio, mes, 1).isoformat(), fecha_en_mes(anio, mes, 31).isoformat()
    aho = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE tipo='ahorro' AND fecha BETWEEN ? AND ?",
                       (ini, fin)).fetchone()[0]
    extras = sum(mi_monto(m, props) for m in movs if m["tipo"] == "ingreso" and not m["fijo_id"] and not m["origen"]
                 and not m["contrato_id"] and not m["cobro_id"])
    cobros = sum(m["monto"] for m in movs if m["tipo"] == "ingreso" and m["cobro_id"])
    prestado = sum(m["monto"] for m in movs if m["tipo"] == "gasto" and m["cobro_id"])
    portal = sum(m["monto"] for m in movs if m["tipo"] == "ingreso" and m["origen"])
    variables = sum(mi_monto(m, props) for m in movs if m["tipo"] == "gasto" and not m["fijo_id"] and not m["deuda_id"]
                    and not m["cobro_id"])
    abonos = sum(m["monto"] for m in movs if m["deuda_id"])
    gfijos = sum(mi_monto(m, props) for m in movs if m["tipo"] == "gasto" and m["fijo_id"])
    gravable = sum(mi_monto(m, props) for m in movs if m["tipo"] == "ingreso" and m["categoria"] in cats_impuestos())
    imp = db().execute("SELECT id FROM ahorros WHERE tipo='impuestos' AND activo=1").fetchone()
    apartado_imp = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE ahorro_id=? AND monto>0 "
                                "AND fecha BETWEEN ? AND ?", (imp[0] if imp else -1, ini, fin)).fetchone()[0]
    toca_imp = round(gravable * pct_impuestos() / 100, 2)
    return {"movs": movs, "ing": ing, "gas": gas, "porcat": porcat, "aho": round(aho, 2),
            "extras": round(extras, 2), "portal": round(portal, 2), "cobros": round(cobros, 2), "prestado": round(prestado, 2), "variables": round(variables, 2),
            "abonos": round(abonos, 2), "gfijos": round(gfijos, 2), "queda": round(ing - gas - aho, 2),
            "gravable": round(gravable, 2), "toca_imp": toca_imp, "apartado_imp": round(apartado_imp, 2),
            "falta_imp": round(max(0, toca_imp - apartado_imp), 2), "imp_id": imp[0] if imp else None}


def estado_limites(porcat, anio, mes):
    hoy = date.today()
    ultimo = fecha_en_mes(anio, mes, 31).day
    avance = 1.0 if (anio, mes) < (hoy.year, hoy.month) else (hoy.day / ultimo if (anio, mes) == (hoy.year, hoy.month) else 0)
    res = []
    for l in db().execute("SELECT * FROM limites WHERE monto>0 ORDER BY categoria"):
        usado = porcat.get(l["categoria"], 0)
        pct = usado / l["monto"] * 100
        color = "mal" if pct > 100 else ("ojo" if pct >= 80 else "ok")
        res.append({"cat": l["categoria"], "limite": l["monto"], "usado": round(usado, 2), "pct": pct,
                    "queda": round(l["monto"] - usado, 2), "color": color, "icono": ICONOS.get(l["categoria"], "•"),
                    "adelantado": avance and pct / 100 > avance + 0.15 and pct <= 100})
    return sorted(res, key=lambda x: -x["pct"])


def estado_ahorros():
    res = []
    gasto_mes = sum((f["monto"] or 0) / (f["cada"] or 1) for f in db().execute(
        "SELECT monto, cada FROM fijos WHERE activo=1 AND tipo='gasto' AND propiedad_id IS NULL"))
    gasto_mes += sum(l["monto"] for l in db().execute("SELECT monto FROM limites"))
    for a in db().execute("SELECT * FROM ahorros WHERE activo=1 ORDER BY id"):
        saldo = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE ahorro_id=?", (a["id"],)).fetchone()[0]
        meta, auto = a["meta"], False
        if not meta and a["tipo"] == "emergencia":
            meta, auto = round(gasto_mes * 3, -2), True
        res.append({"a": a, "saldo": round(saldo, 2), "meta": meta, "auto": auto,
                    "pct": min(100, saldo / meta * 100) if meta else None})
    return res, round(gasto_mes, 2)


def proxima_fecha_irs(hoy=None):
    hoy = hoy or date.today()
    for anio in (hoy.year, hoy.year + 1):
        for m, d in FECHAS_IRS:
            f = date(anio, m, d)
            if f >= hoy:
                return f


def simular_deudas(lista, presupuesto, metodo):
    """Mes a mes: intereses, mínimos y todo lo extra a la deuda que toca según el método."""
    ds = [{"nombre": x["d"]["nombre"], "saldo": x["saldo"], "apr": (x["d"]["interes"] or 0) / 100,
           "min": x["d"]["minimo"] or 0, "fin": None} for x in lista if x["saldo"] > 0]
    if not ds:
        return None
    if metodo == "avalancha":
        orden = sorted(ds, key=lambda d: (-d["apr"], d["saldo"]))
    else:
        orden = sorted(ds, key=lambda d: (d["saldo"], -d["apr"]))
    minimos = sum(d["min"] for d in ds)
    if presupuesto < minimos:
        return {"error": f"Con {dinero(presupuesto)} al mes no alcanza para los mínimos ({dinero(minimos)})."}
    interes_total, mes = 0.0, 0
    while any(d["saldo"] > 0.005 for d in ds) and mes < 600:
        mes += 1
        for d in ds:
            if d["saldo"] > 0:
                i = d["saldo"] * d["apr"] / 12
                d["saldo"] += i; interes_total += i
        disponible = presupuesto
        for d in ds:
            if d["saldo"] > 0:
                p = min(d["min"], d["saldo"]); d["saldo"] -= p; disponible -= p
        for d in orden:
            if disponible <= 0: break
            if d["saldo"] > 0:
                p = min(disponible, d["saldo"]); d["saldo"] -= p; disponible -= p
        for d in ds:
            if d["saldo"] <= 0.005 and d["fin"] is None:
                d["fin"] = mes
    if mes >= 600:
        return {"error": "Con ese monto los intereses no te dejan bajar las deudas. Prueba con más."}
    hoy = date.today()
    mes_a_fecha = lambda n: date(hoy.year + (hoy.month - 1 + n) // 12, (hoy.month - 1 + n) % 12 + 1, 1)
    return {"meses": mes, "interes": round(interes_total, 2), "fin": mes_a_fecha(mes),
            "orden": [{"nombre": d["nombre"], "mes": d["fin"], "fecha": mes_a_fecha(d["fin"])} for d in orden],
            "primera": orden[0]["nombre"]}


def objetivo_deuda(lista):
    """A cuál meterle lo extra: según tu plan si lo tienes, si no la más chica."""
    plan = num(ajuste("plan_mensual", defecto="")) or 0
    metodo = ajuste("plan_metodo", defecto="avalancha")
    vivas = [x for x in lista if x["saldo"] > 0]
    if not vivas:
        return None
    if plan:
        s = simular_deudas(vivas, plan, metodo)
        if s and "primera" in s:
            return next(x for x in vivas if x["d"]["nombre"] == s["primera"])
    return min(vivas, key=lambda x: x["saldo"])


def guardar_recibo(archivo, mid):
    """Guarda la foto del recibo achicada (para que no ocupe mucho)."""
    if not archivo or not archivo.filename:
        return
    datos = archivo.read()
    if not datos:
        return
    os.makedirs(RECIBOS, exist_ok=True)
    nombre = f"{mid}-{secrets.token_hex(4)}.jpg"
    try:
        from PIL import Image, ImageOps
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(datos))).convert("RGB")
        im.thumbnail((1600, 1600))
        im.save(os.path.join(RECIBOS, nombre), "JPEG", quality=80)
    except Exception:
        ext = os.path.splitext(archivo.filename)[1].lower()
        if ext not in (".jpg", ".jpeg", ".png", ".heic", ".webp", ".pdf"):
            return
        nombre = nombre[:-4] + ext
        with open(os.path.join(RECIBOS, nombre), "wb") as f:
            f.write(datos)
    db().execute("UPDATE movimientos SET recibo=? WHERE id=?", (nombre, mid))


def borrar_recibo(nombre):
    if nombre:
        try:
            os.remove(os.path.join(RECIBOS, os.path.basename(nombre)))
        except OSError:
            pass


ESTADOS_PROP = ["Alquilada", "Vacía", "En obra gris", "En venta", "Uso propio"]
TIPOS_PROP = ["Apartamento", "Casa", "Local", "Terreno", "Oficina", "Otro"]
TIPOS_DOC = ["Reserva", "Compra / documento de venta", "Registro", "Pago", "Planos o permisos", "Otro"]
EXT_DOC = (".pdf", ".jpg", ".jpeg", ".png", ".heic", ".webp")


def datos_propiedad(p, anio=None):
    anio = anio or date.today().year
    f = (p["parte"] or 0) / 100
    activos = db().execute("SELECT * FROM contratos WHERE propiedad_id=? AND estado='activo' ORDER BY unidad, inicio",
                           (p["id"],)).fetchall()
    renta = sum(c["monto"] or 0 for c in activos)
    q = lambda tipo, extra="", args=(): db().execute(
        f"SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE propiedad_id=? AND tipo=? {extra}", (p["id"], tipo) + args).fetchone()[0]
    cob_anio, gas_anio = q("ingreso", "AND substr(fecha,1,4)=?", (str(anio),)), q("gasto", "AND substr(fecha,1,4)=?", (str(anio),))
    cob_total, gas_total = q("ingreso"), q("gasto")
    costo, valor = p["costo"] or 0, (p["valor_actual"] if p["valor_actual"] is not None else (p["costo"] or 0))
    hoy = date.today()
    vence = [c for c in activos if c["fin"] and (date.fromisoformat(c["fin"]) - hoy).days <= 60]
    estado = p["estado"] or ("Alquilada" if activos else "Vacía")
    anios = None
    if p["fecha_compra"]:
        try:
            anios = (hoy - date.fromisoformat(p["fecha_compra"])).days / 365.25
        except ValueError:
            anios = None
    sube_anual = ((valor / costo) ** (1 / anios) - 1) * 100 if (anios and anios >= 0.5 and costo and valor) else None
    return {"anios": anios, "sube_anual": sube_anual, "p": p, "f": f, "activos": activos, "renta": renta, "renta_tuya": renta * f,
            "costo": costo, "valor": valor, "costo_tuyo": costo * f, "valor_tuyo": valor * f,
            "plusvalia": valor - costo, "plusvalia_tuya": (valor - costo) * f,
            "plusvalia_pct": ((valor - costo) / costo * 100) if costo else 0,
            "rend_pct": (renta * 12 / costo * 100) if costo else 0,
            "cob_anio": cob_anio, "gas_anio": gas_anio, "neto_anio_tuyo": (cob_anio - gas_anio) * f,
            "cob_total": cob_total, "gas_total": gas_total, "neto_total_tuyo": (cob_total - gas_total) * f,
            "vence": vence, "estado": estado}


def resumen_inversiones():
    lista = [datos_propiedad(p) for p in db().execute("SELECT * FROM propiedades WHERE activa=1 ORDER BY nombre")]
    t = {k: sum(x[k] for x in lista) for k in ("costo_tuyo", "valor_tuyo", "plusvalia_tuya", "renta_tuya", "neto_anio_tuyo")}
    t["plusvalia_pct"] = (t["plusvalia_tuya"] / t["costo_tuyo"] * 100) if t["costo_tuyo"] else 0
    t["rend_pct"] = (t["renta_tuya"] * 12 / t["costo_tuyo"] * 100) if t["costo_tuyo"] else 0
    return lista, t


def estado_por_cobrar(todas=False):
    res = []
    hoy = date.today()
    for d in db().execute("SELECT * FROM por_cobrar" + ("" if todas else " WHERE activa=1") + " ORDER BY activa DESC, persona"):
        cob = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE cobro_id=? AND tipo='ingreso'", (d["id"],)).fetchone()[0]
        cobrado = (d["cobrado_antes"] or 0) + cob
        saldo = max(0, (d["monto"] or 0) - cobrado)
        ult = db().execute("SELECT fecha, monto FROM movimientos WHERE cobro_id=? AND tipo='ingreso' ORDER BY fecha DESC, id DESC LIMIT 1",
                           (d["id"],)).fetchone()
        vencida = bool(d["vence"] and saldo > 0 and d["vence"] < hoy.isoformat())
        res.append({"d": d, "cobrado": cobrado, "saldo": saldo, "ultimo": ult, "vencida": vencida,
                    "pct": (cobrado / d["monto"] * 100) if d["monto"] else 0})
    return res


def patrimonio_actual(guardar=True):
    _, inv = resumen_inversiones()
    ahorros = sum(x["saldo"] for x in estado_ahorros()[0])
    ahorros += sum(e["neto"] for e in susus_activos())  # lo que has puesto en susus y aún no cobras
    ahorros += sum(e["rescate"] for e in polizas_activas())  # lo que te darían hoy si cancelas el seguro
    deudas = sum(x["saldo"] for x in estado_deudas())
    me_deben = sum(x["saldo"] for x in estado_por_cobrar())
    total = round(inv["valor_tuyo"] + ahorros + me_deben - deudas, 2)
    if guardar:
        db().execute("INSERT INTO patrimonio(mes, total, propiedades, ahorros, deudas, me_deben) VALUES(?,?,?,?,?,?) "
                     "ON CONFLICT(mes) DO UPDATE SET total=excluded.total, propiedades=excluded.propiedades, "
                     "ahorros=excluded.ahorros, deudas=excluded.deudas, me_deben=excluded.me_deben",
                     (date.today().strftime("%Y-%m"), total, inv["valor_tuyo"], ahorros, deudas, me_deben))
        db().commit()
    hist = db().execute("SELECT * FROM patrimonio ORDER BY mes DESC LIMIT 12").fetchall()[::-1]
    antes = hist[-2]["total"] if len(hist) >= 2 else None
    return {"total": total, "propiedades": inv["valor_tuyo"], "ahorros": ahorros, "deudas": deudas, "me_deben": me_deben,
            "hist": hist, "cambio": (total - antes) if antes is not None else None}


def meses_atras(n, hasta=None):
    d = (hasta or date.today()).replace(day=1)
    res = []
    for _ in range(n):
        res.append((d.year, d.month))
        d = (d - timedelta(days=1)).replace(day=1)
    return res[::-1]


def grafica_meses(n=6):
    """Barras: lo que entró y lo que salió en los últimos n meses (tu parte)."""
    datos = []
    for a, m in meses_atras(n):
        _, i, g, _ = totales_mes(a, m)
        datos.append({"mes": MESES[m - 1][:3], "nombre": f"{MESES[m - 1]} {a}", "ing": i, "gas": g, "ym": f"{a}-{m:02d}"})
    tope = max([max(d["ing"], d["gas"]) for d in datos] + [1])
    for d in datos:
        d["hi"], d["hg"] = d["ing"] / tope, d["gas"] / tope
    return datos, tope


def linea_patrimonio(hist, ancho=300, alto=56):
    if len(hist) < 2:
        return None
    vals = [h["total"] for h in hist]
    lo, hi = min(vals), max(vals)
    rango = (hi - lo) or 1
    pts = [(i * ancho / (len(vals) - 1), alto - 4 - (v - lo) / rango * (alto - 8)) for i, v in enumerate(vals)]
    return {"d": " ".join(f"{'M' if i == 0 else 'L'}{x:.1f},{y:.1f}" for i, (x, y) in enumerate(pts)),
            "ultimo": pts[-1], "ancho": ancho, "alto": alto}


def calendario(dias=45):
    hoy = date.today()
    fin = hoy + timedelta(days=dias)
    items = []
    d = hoy.replace(day=1)
    while d <= fin:
        for e in eventos_mes(d.year, d.month, desde_creado=False):
            if (e["fecha"] >= hoy or (e["estado"] == "atrasado" and d.month == hoy.month)) and e["fecha"] <= fin:
                items.append(e)
        d = (d + timedelta(days=32)).replace(day=1)
    for c in db().execute("SELECT c.*, p.nombre pn FROM contratos c JOIN propiedades p ON p.id=c.propiedad_id "
                          "WHERE c.estado='activo' AND p.activa=1 AND c.fin BETWEEN ? AND ?", (hoy.isoformat(), fin.isoformat())):
        items.append({"clave": f"v{c['id']}", "nombre": f"Vence contrato {c['pn']}" + (f" ({c['unidad']})" if c["unidad"] else ""),
                      "tipo": "aviso", "fecha": date.fromisoformat(c["fin"]), "hecho": None, "estado": "aviso",
                      "sugerido": c["deposito_devolver"] or 0, "factor": 1, "frecuencia": "Depósito a devolver" if c["deposito_devolver"] else ""})
    for x in estado_por_cobrar():
        if x["saldo"] > 0 and x["d"]["vence"] and hoy.isoformat() <= x["d"]["vence"] <= fin.isoformat():
            items.append({"clave": f"m{x['d']['id']}", "nombre": f"{x['d']['persona']} te debe pagar", "tipo": "ingreso",
                          "fecha": date.fromisoformat(x["d"]["vence"]), "hecho": None, "estado": "luego",
                          "sugerido": x["saldo"], "factor": 1, "frecuencia": x["d"]["concepto"] or "", "categoria": "Me pagaron lo que me debían"})
    for ag in db().execute("SELECT * FROM agenda WHERE estado='pendiente' AND fecha<=? ORDER BY fecha", (fin.isoformat(),)):
        fe = date.fromisoformat(ag["fecha"])
        items.append({"clave": f"a{ag['id']}", "nombre": f"Pagar {ag['nombre']}", "tipo": "gasto", "fecha": fe, "hecho": None,
                      "estado": "atrasado" if fe < hoy else "agendado", "sugerido": ag["monto"] or 0, "factor": 1,
                      "frecuencia": (ag["nota"] or "") + (" · cada mes" if ag["mensual"] else ""),
                      "categoria": "Tarjetas y deudas", "agenda_id": ag["id"]})
    for e in susus_activos():
        nom_s = e["s"]["nombre"] if e["s"]["nombre"].lower().startswith("susu") else "Susu " + e["s"]["nombre"]
        for r in e["rondas"]:
            if not r["pagada"] and r["fecha"] <= fin and r["total"]:
                items.append({"clave": f"s{r['t']['id']}", "nombre": f"{nom_s} · turno {r['n']}", "tipo": "gasto",
                              "fecha": r["fecha"], "hecho": None, "estado": "atrasado" if r["fecha"] < hoy else "agendado",
                              "sugerido": r["total"], "factor": 1, "categoria": "Susu",
                              "frecuencia": " + ".join(m["nombre"] for m in r["manos"]) if len(r["manos"]) > 1 else ""})
        for r in e["mio"]:
            if not r["t"]["cobrado"] and hoy <= r["fecha"] <= fin:
                items.append({"clave": f"S{r['t']['id']}", "nombre": f"Cobras: {nom_s}", "tipo": "ingreso",
                              "fecha": r["fecha"], "hecho": None, "estado": "luego", "sugerido": e["bote"], "factor": 1,
                              "categoria": "Susu", "frecuencia": "Tu turno"})
    irs = proxima_fecha_irs()
    if irs and irs <= fin:
        items.append({"clave": "irs", "nombre": "Pago estimado al IRS", "tipo": "aviso", "fecha": irs, "hecho": None,
                      "estado": "aviso", "sugerido": 0, "factor": 1, "frecuencia": ""})
    if ajuste("enlace"):
        for k in range(0, 3):
            base = (hoy.replace(day=1) + timedelta(days=32 * k)).replace(day=1)
            for dd in (5, 20):
                fe = base.replace(day=dd)
                if hoy <= fe <= fin:
                    items.append({"clave": f"t{fe}", "nombre": "Ganancia Talavera (llega sola)", "tipo": "ingreso", "fecha": fe,
                                  "hecho": None, "estado": "auto", "sugerido": 0, "factor": 1, "frecuencia": ""})
    return sorted(items, key=lambda x: (x["fecha"], x["tipo"] != "aviso"))


# ---------- enlace con el portal de la compañía ----------
def sincronizar_portal(con=None):
    """Trae la ganancia de cada quincena publicada y la pone como ingreso (Talavera Services)."""
    propia = con is None
    con = con or sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        r = con.execute("SELECT valor FROM ajustes WHERE clave='enlace'").fetchone()
        if not r or "|" not in r[0]:
            return None, "No está enlazado."
        url, clave = r[0].split("|", 1)
        req = urllib.request.Request(url.rstrip("/") + "/api/ganancias", headers={"X-Clave": clave,
                                                                                  "User-Agent": "finanzas"})
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                datos = json.load(resp)
        except urllib.error.HTTPError as e:
            return None, ("El código no es válido. Copia uno nuevo del portal de la compañía."
                          if e.code in (401, 403) else f"El portal de la compañía respondió con error {e.code}.")
        except Exception:
            return None, "No pude conectar con el portal de la compañía. Revisa la dirección."
        cr = con.execute("SELECT valor FROM ajustes WHERE clave='creado'").fetchone()
        desde = (date.fromisoformat(cr[0]).replace(day=1) - timedelta(days=31)).isoformat() if cr else "2000-01-01"
        cambios = 0
        for q in datos.get("quincenas", []):
            if not q.get("publicada") or q["fin"] < desde:
                continue
            origen = f"portal:q{int(q['id'])}"
            fe = (date.fromisoformat(q["fin"]) + timedelta(days=5)).isoformat()
            ini, fin = date.fromisoformat(q["inicio"]), date.fromisoformat(q["fin"])
            nota = f"Ganancia quincena {ini.day}–{fin.day} {MESES[fin.month - 1][:3]}"
            monto = round(float(q["ganancia"]), 2)
            ya = con.execute("SELECT * FROM movimientos WHERE origen=?", (origen,)).fetchone()
            if monto <= 0:
                if ya:
                    con.execute("DELETE FROM movimientos WHERE id=?", (ya["id"],)); cambios += 1
                continue
            if not ya:
                con.execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, origen) VALUES('ingreso',?,?,?,?,?)",
                            (fe, monto, "Sueldo / Trabajo", nota, origen))
                con.execute("INSERT INTO historial(cuando, texto) VALUES(?,?)",
                            (datetime.now().strftime("%Y-%m-%d %H:%M"), f"Llegó del portal: {nota} {dinero(monto)}"))
                cambios += 1
            elif abs(ya["monto"] - monto) > 0.005 or ya["fecha"] != fe:
                con.execute("UPDATE movimientos SET monto=?, fecha=?, nota=? WHERE id=?", (monto, fe, nota, ya["id"]))
                con.execute("INSERT INTO historial(cuando, texto) VALUES(?,?)",
                            (datetime.now().strftime("%Y-%m-%d %H:%M"),
                             f"Se actualizó del portal: {nota} {dinero(ya['monto'])} → {dinero(monto)}"))
                cambios += 1
        con.execute("INSERT INTO ajustes(clave, valor) VALUES('ultima_sync', ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                    (datetime.now().strftime("%Y-%m-%d %H:%M"),))
        con.commit()
        return cambios, None
    finally:
        if propia:
            con.close()


def sync_en_fondo():
    while True:
        try:
            sincronizar_portal()
        except Exception:
            pass
        time.sleep(2 * 3600)


# ---------- páginas ----------
@app.route("/mes")
@app.route("/inicio")
@requiere
def inicio():
    anio, mes = mes_param()
    movs, ing, gas, porcat = totales_mes(anio, mes)
    pend = pendientes_mes(anio, mes)
    falta_g = sum(p["sugerido"] * p["factor"] for p in pend if not p["hecho"] and p["tipo"] == "gasto")
    falta_i = sum(p["sugerido"] * p["factor"] for p in pend if not p["hecho"] and p["tipo"] == "ingreso")
    ant = date(anio, mes, 1) - timedelta(days=1)
    sig = fecha_en_mes(anio, mes, 31) + timedelta(days=1)
    props = propiedades()
    avisos = []
    r = resumen_mes(anio, mes)
    hoy = date.today()
    es_actual = (anio, mes) == (hoy.year, hoy.month)
    # pago estimado al IRS que viene
    irs = proxima_fecha_irs()
    aviso_irs = None
    if irs and (irs - hoy).days <= 21 and r["imp_id"]:
        saldo_imp = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE ahorro_id=?",
                                 (r["imp_id"],)).fetchone()[0]
        aviso_irs = {"fecha": irs, "dias": (irs - hoy).days, "saldo": saldo_imp}
    # cierre del mes pasado
    pasado = (hoy.replace(day=1) - timedelta(days=1))
    cierre = None
    if pasado.replace(day=1) >= creado_desde() and not ajuste(f"cierre_{pasado:%Y-%m}"):
        cierre = {"mes": f"{pasado:%Y-%m}", "nombre": MESES[pasado.month - 1]}
    # enlace con la compañía y un fijo de Talavera repetido
    enlazado = bool(ajuste("enlace"))
    if enlazado and db().execute("SELECT 1 FROM fijos WHERE activo=1 AND tipo='ingreso' AND categoria='Talavera Services'").fetchone():
        avisos.append("Tu ganancia de Talavera ya llega sola del portal de la compañía. Quita el ingreso fijo "
                      "«Talavera Services» en Fijos para que no se cuente dos veces.")
    # lo que más repites, para anotarlo con un toque
    recientes = db().execute(
        "SELECT nota, categoria, COUNT(*) n FROM movimientos WHERE tipo='gasto' AND fijo_id IS NULL AND deuda_id IS NULL "
        "AND propiedad_id IS NULL AND nota<>'' AND categoria NOT IN ('Impuestos','Tarjetas y deudas') AND fecha>=? GROUP BY lower(nota), categoria ORDER BY n DESC, MAX(id) DESC LIMIT 6",
        ((hoy - timedelta(days=90)).isoformat(),)).fetchall()
    return render_template("inicio.html", anio=anio, mes=mes, r=r, nombre_mes=MESES[mes - 1], movs=movs, ing=ing, gas=gas,
                           porcat=porcat, pend=pend, falta_g=round(falta_g, 2), falta_i=round(falta_i, 2),
                           ant=ant.strftime("%Y-%m"), sig=sig.strftime("%Y-%m"), props=props, avisos=avisos,
                           es_actual=es_actual, limites=estado_limites(porcat, anio, mes), aviso_irs=aviso_irs,
                           cierre=cierre, recientes=recientes, iconos=ICONOS, cat_extra=CAT_EXTRA,
                           cat_rapido=[c for c in CAT_GASTO if c not in ("Tarjetas y deudas", "Impuestos", "Propiedades", "Préstamos que hice")],
                           pct_imp=pct_impuestos(), enlazado=enlazado,
                           cat_gasto=CAT_GASTO, cat_ingreso=CAT_INGRESO, hoy=hoy.isoformat())


@app.post("/movimiento")
@requiere
def movimiento():
    acc = request.form.get("accion")
    v = request.form.get("volver", "")
    volver = redirect(v if v.startswith("/") and not v.startswith("//") else url_for("inicio", mes=request.form.get("mes")))
    if acc == "borrar":
        m = db().execute("SELECT * FROM movimientos WHERE id=?", (request.form.get("id", type=int),)).fetchone()
        if m:
            db().execute("DELETE FROM movimientos WHERE id=?", (m["id"],))
            borrar_recibo(m["recibo"])
            anotar(f"Borraste {m['tipo']} de ${m['monto']:,.2f} ({m['categoria']}, {m['fecha']})")
    elif acc == "recibo":
        m = db().execute("SELECT * FROM movimientos WHERE id=?", (request.form.get("id", type=int),)).fetchone()
        if m:
            borrar_recibo(m["recibo"])
            guardar_recibo(request.files.get("recibo"), m["id"])
            flash("Foto del recibo guardada.")
    elif acc == "fijo" and request.form.get("clave", "").startswith("c"):  # alquiler de un contrato
        c = db().execute("SELECT * FROM contratos WHERE id=?", (int(request.form["clave"][1:] or 0),)).fetchone() or abort(404)
        p = db().execute("SELECT * FROM propiedades WHERE id=?", (c["propiedad_id"],)).fetchone()
        monto, oc = num(request.form.get("monto")), request.form.get("ocurrencia", "")
        if monto is None or monto < 0 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", oc):
            flash("Escribe un monto válido.")
            return volver
        nombre = f"Alquiler {p['nombre']}" + (f" ({c['unidad']})" if c["unidad"] else "")
        db().execute("DELETE FROM movimientos WHERE contrato_id=? AND ocurrencia=?", (c["id"], oc))
        db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, contrato_id, ocurrencia, propiedad_id) "
                     "VALUES('ingreso',?,?,?,?,?,?,?)", (oc, monto, "Alquileres", nombre, c["id"], oc, p["id"]))
        anotar(f"Confirmaste «{nombre}» de ${monto:,.2f} ({oc})")
    elif acc == "fijo":
        clave = request.form.get("clave", "")
        fid = int(clave[1:]) if re.fullmatch(r"f\d+", clave) else request.form.get("fijo", type=int)
        f = db().execute("SELECT * FROM fijos WHERE id=?", (fid,)).fetchone() or abort(404)
        monto, oc = num(request.form.get("monto")), request.form.get("ocurrencia", "")
        if monto is None or monto < 0 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", oc):
            flash("Escribe un monto válido.")
            return volver
        db().execute("DELETE FROM movimientos WHERE fijo_id=? AND ocurrencia=?", (f["id"], oc))
        db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, fijo_id, ocurrencia, propiedad_id) "
                     "VALUES(?,?,?,?,?,?,?,?)", (f["tipo"], oc, monto, f["categoria"], f["nombre"], f["id"], oc,
                                                 f["propiedad_id"]))
        anotar(f"Confirmaste «{f['nombre']}» de ${monto:,.2f} ({oc})")
    else:
        tipo = "ingreso" if request.form.get("tipo") == "ingreso" else "gasto"
        monto = num(request.form.get("monto"))
        fe = request.form.get("fecha") or date.today().isoformat()
        if not monto or monto <= 0:
            flash("Escribe el monto.")
            return volver
        pid = request.form.get("propiedad", type=int) or None
        cat = request.form.get("categoria") or ("Otros" if tipo == "gasto" else "Otros ingresos")
        nota = request.form.get("nota", "").strip()
        if request.form.get("rapido") and "||" in request.form["rapido"]:  # lo que más repites, con un toque
            cat, nota = request.form["rapido"].split("||", 1)
        if cat not in (CAT_GASTO if tipo == "gasto" else CAT_INGRESO):
            cat = "Otros" if tipo == "gasto" else "Otros ingresos"
        if pid and tipo == "gasto":
            cat = "Propiedades"
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fe):
            fe = date.today().isoformat()
        cur = db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, propiedad_id) VALUES(?,?,?,?,?,?)",
                           (tipo, fe, monto, cat, nota[:120], pid))
        guardar_recibo(request.files.get("recibo"), cur.lastrowid)
        anotar(f"Anotaste {tipo} de ${monto:,.2f} ({cat})")
        aviso = f"{'Ingreso' if tipo == 'ingreso' else 'Gasto'} de ${monto:,.2f} anotado en {cat}."
        if tipo == "gasto":
            lim = db().execute("SELECT monto FROM limites WHERE categoria=?", (cat,)).fetchone()
            if lim and lim[0] > 0:
                usado = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE tipo='gasto' AND categoria=? "
                                     "AND substr(fecha,1,7)=?", (cat, fe[:7])).fetchone()[0]
                aviso += (f" Te quedan {dinero(lim[0] - usado)} de tu límite." if usado <= lim[0]
                          else f" ⚠️ Te pasaste {dinero(usado - lim[0])} de tu límite de {dinero(lim[0])}.")
        elif cat in cats_impuestos():
            aviso += f" Aparta {dinero(monto * pct_impuestos() / 100)} para impuestos."
        flash(aviso)
        db().commit()
        return volver if v.startswith("/") and not v.startswith("//") else redirect(url_for("inicio", mes=fe[:7]))
    db().commit()
    return volver


@app.route("/fijos", methods=["GET", "POST"])
@requiere
def fijos():
    if request.method == "POST":
        acc = request.form.get("accion")
        if acc == "quitar":
            f = db().execute("SELECT * FROM fijos WHERE id=?", (request.form.get("id", type=int),)).fetchone()
            db().execute("UPDATE fijos SET activo=0 WHERE id=?", (request.form.get("id", type=int),))
            if f: anotar(f"Quitaste el fijo «{f['nombre']}»")
        else:
            nombre = request.form.get("nombre", "").strip()[:80]
            tipo = "ingreso" if request.form.get("tipo") == "ingreso" else "gasto"
            dias = ",".join(str(d) for d in sorted({int(d) for d in re.findall(r"\d+", request.form.get("dias", "1"))
                                                     if 1 <= int(d) <= 31})) or "1"
            cada = request.form.get("cada", type=int) or 1
            cada = cada if cada in FRECUENCIAS else 1
            mi = request.form.get("mes_inicio", "")[:7]
            if cada > 1 and not re.fullmatch(r"\d{4}-\d{2}", mi):
                mi = date.today().strftime("%Y-%m")
            # préstamo con interés: monto prestado × % = lo que recibe
            capital, pct = num(request.form.get("capital")), num(request.form.get("interes"))
            periodo = "anio" if request.form.get("interes_periodo") == "anio" else "mes"
            categoria = request.form.get("categoria")
            monto = num(request.form.get("monto")) or 0
            if tipo == "ingreso" and capital and capital > 0 and pct and pct > 0:
                monto = round(capital * pct / 100 / (12 if periodo == "anio" else 1), 2)
                if cada > 1:  # si cobra cada varios meses, recibe los intereses de esos meses juntos
                    monto = round(monto * cada, 2)
                categoria = "Intereses de préstamos"
            else:
                capital = pct = periodo = None
            if nombre:
                fid = request.form.get("id", type=int)
                vals = (tipo, nombre, categoria, monto, dias, cada, mi if cada > 1 else None, capital, pct, periodo)
                if fid:
                    db().execute("UPDATE fijos SET tipo=?, nombre=?, categoria=?, monto=?, dias=?, cada=?, mes_inicio=?, "
                                 "capital=?, interes=?, interes_periodo=? WHERE id=?", vals + (fid,))
                    anotar(f"Editaste el fijo «{nombre}»")
                    flash(f"«{nombre}» guardado.")
                else:
                    db().execute("INSERT INTO fijos(tipo, nombre, categoria, monto, dias, cada, mes_inicio, capital, interes, "
                                 "interes_periodo, desde) VALUES(?,?,?,?,?,?,?,?,?,?,?)", vals + (date.today().isoformat(),))
                    anotar(f"Agregaste el fijo «{nombre}» (día {dias}, {FRECUENCIAS[cada].lower()})")
                    flash(f"«{nombre}» agregado. Te va a salir " + ("cada mes" if cada == 1 else FRECUENCIAS[cada].lower()) + " para confirmarlo.")
        db().commit()
        return redirect(url_for("fijos"))
    lista = db().execute("SELECT * FROM fijos WHERE activo=1 AND propiedad_id IS NULL ORDER BY tipo DESC, nombre").fetchall()
    mensual = sum(f["monto"] / (f["cada"] or 1) * len(dias_de(f)) for f in lista if f["tipo"] == "gasto")
    reserva = sum(f["monto"] / f["cada"] for f in lista if f["tipo"] == "gasto" and (f["cada"] or 1) > 1)
    # fijos temporales: los susus, aparte de los fijos normales
    hoy = date.today()
    temporales = []
    for e in susus_activos():
        mes = [r for r in e["rondas"] if r["fecha"].year == hoy.year and r["fecha"].month == hoy.month]
        faltan = [r for r in e["rondas"] if not r["pagada"]]
        if not faltan and not mes:
            continue
        temporales.append({"e": e, "mes": sum(r["total"] for r in mes), "n_mes": len(mes),
                           "pagado_mes": sum(r["total"] for r in mes if r["pagada"]),
                           "faltan": len(faltan), "falta_total": sum(r["total"] for r in faltan),
                           "termina": e["rondas"][-1]["fecha"] if e["rondas"] else None, "manos": e["manos"]})
    temp_mes = sum(t["mes"] for t in temporales)
    prestamos = [f for f in lista if f["tipo"] == "ingreso" and f["capital"]]
    prest = {"n": len(prestamos), "capital": sum(f["capital"] for f in prestamos),
             "mes": sum(f["monto"] / (f["cada"] or 1) * len(dias_de(f)) for f in prestamos)}
    return render_template("fijos.html", prest=prest, temporales=temporales, temp_mes=temp_mes, lista=lista, cat_gasto=CAT_GASTO, cat_ingreso=CAT_INGRESO, frecuencias=FRECUENCIAS,
                           mensual=mensual, reserva=reserva, hoy_mes=date.today().strftime("%Y-%m"), iconos=ICONOS)


@app.route("/resumen")
@requiere
def resumen():
    hoy = date.today()
    pat = patrimonio_actual()
    r = resumen_mes(hoy.year, hoy.month)
    pend = pendientes_mes(hoy.year, hoy.month)
    falta_g = sum(p["sugerido"] * p["factor"] for p in pend if not p["hecho"] and p["tipo"] == "gasto")
    falta_i = sum(p["sugerido"] * p["factor"] for p in pend if not p["hecho"] and p["tipo"] == "ingreso")
    barras, tope = grafica_meses(6)
    inv_lista, inv = resumen_inversiones()
    alertas = []
    for x in inv_lista:
        for c in x["vence"]:
            dias = (date.fromisoformat(c["fin"]) - hoy).days
            alertas.append({"texto": f"El contrato de {x['p']['nombre']}{' (' + c['unidad'] + ')' if c['unidad'] else ''} "
                                     + (f"vence en {dias} días." if dias >= 0 else "ya venció."),
                            "url": url_for("ver_propiedad", pid=x["p"]["id"])})
    for e in pend:
        if e["clave"].startswith("c") and e["estado"] == "atrasado":
            alertas.append({"texto": f"No has confirmado «{e['nombre']}» del {fecha(e['fecha'])}.",
                            "url": url_for("inicio") + "#fijos"})
    for x in estado_por_cobrar():
        if x["vencida"]:
            alertas.append({"texto": f"{x['d']['persona']} te debía pagar {dinero(x['saldo'])} el {fecha(x['d']['vence'])}.",
                            "url": url_for("me_deben")})
    for ag in db().execute("SELECT * FROM agenda WHERE estado='pendiente' AND fecha<=? ORDER BY fecha",
                           ((hoy + timedelta(days=1)).isoformat(),)):
        fe = date.fromisoformat(ag["fecha"])
        cuando = "hoy" if fe == hoy else ("mañana" if fe > hoy else f"el {fecha(fe)} y no lo has marcado")
        alertas.append({"texto": f"{'Tenías agendado' if fe < hoy else 'Agendaste'} pagar {ag['nombre']} ({dinero(ag['monto'] or 0)}) {cuando}.",
                        "url": url_for("deudas") + "#agenda"})
    irs = proxima_fecha_irs()
    if irs and (irs - hoy).days <= 21:
        alertas.append({"texto": f"El {fecha(irs)} toca el pago estimado al IRS.", "url": url_for("ahorros")})
    pasado = hoy.replace(day=1) - timedelta(days=1)
    cierre = pasado.replace(day=1) >= creado_desde() and not ajuste(f"cierre_{pasado:%Y-%m}")
    metas, _ = estado_ahorros()
    deudas = estado_deudas()
    d_ini = sum(x["d"]["saldo_inicial"] or 0 for x in deudas)
    d_pag = sum(x["abonado"] for x in deudas)
    proximos = [e for e in calendario(10) if e["estado"] not in ("hecho",)][:5]
    def hay(sql):
        return db().execute(sql).fetchone()[0] > 0
    pasos = [
        {"hecho": hay("SELECT COUNT(*) FROM fijos WHERE activo=1 AND tipo='ingreso'"), "texto": "Anota tus ingresos fijos (sueldo, pagos que te llegan cada mes)", "url": url_for("fijos")},
        {"hecho": hay("SELECT COUNT(*) FROM fijos WHERE activo=1 AND tipo='gasto'"), "texto": "Anota tus gastos fijos (renta, teléfono, seguros, carro…)", "url": url_for("fijos")},
        {"hecho": hay("SELECT COUNT(*) FROM deudas"), "texto": "Agrega tus deudas y tarjetas (si tienes)", "url": url_for("deudas")},
        {"hecho": hay("SELECT COUNT(*) FROM propiedades"), "texto": "Agrega tus propiedades o inversiones (si tienes)", "url": url_for("inversiones")},
        {"hecho": hay("SELECT COUNT(*) FROM ahorros WHERE tipo='meta'"), "texto": "Ponte una meta de ahorro", "url": url_for("ahorros")},
        {"hecho": hay("SELECT COUNT(*) FROM llaves"), "texto": "Activa Face ID para entrar más rápido", "url": url_for("ajustes")},
    ]
    if all(x["hecho"] for x in pasos) or ajuste("pasos_ocultos"):
        pasos = None
    return render_template("resumen.html", pasos=pasos, pat=pat, r=r, falta_g=falta_g, falta_i=falta_i, barras=barras, tope=tope,
                           linea=linea_patrimonio(pat["hist"]), inv=inv, alertas=alertas, proximos=proximos,
                           metas=metas, d_saldo=sum(x["saldo"] for x in deudas), d_pct=(d_pag / d_ini * 100) if d_ini else 0,
                           cierre={"mes": f"{pasado:%Y-%m}", "nombre": MESES[pasado.month - 1]} if cierre else None,
                           porcat=list(r["porcat"].items())[:5], nombre_mes=MESES[hoy.month - 1], iconos=ICONOS, hoy=hoy)


@app.route("/calendario")
@requiere
def ver_calendario():
    items = calendario(60)
    grupos = {}
    for e in items:
        grupos.setdefault(e["fecha"], []).append(e)
    sale = sum(e["sugerido"] * e["factor"] for e in items if e["tipo"] == "gasto" and not e["hecho"])
    entra = sum(e["sugerido"] * e["factor"] for e in items if e["tipo"] == "ingreso" and not e["hecho"])
    return render_template("calendario.html", grupos=grupos, sale=sale, entra=entra, hoy=date.today())


@app.route("/mas")
@requiere
def mas():
    return render_template("mas.html")


@app.route("/propiedades")
@requiere
def ver_propiedades():
    return redirect(url_for("inversiones"))


def _campos_propiedad():
    f = request.form
    parte = num(f.get("parte"))
    return {"nombre": f.get("nombre", "").strip()[:80], "tipo": f.get("tipo") if f.get("tipo") in TIPOS_PROP else "Otro",
            "ubicacion": f.get("ubicacion", "").strip()[:120], "costo": num(f.get("costo")) or 0,
            "valor_actual": num(f.get("valor_actual")), "parte": 100 if parte is None else max(0, min(100, parte)),
            "socio": f.get("socio", "").strip()[:60], "estado": f.get("estado") if f.get("estado") in ESTADOS_PROP else None,
            "notas": f.get("notas", "").strip()[:500], "fecha_compra": f.get("fecha_compra") or None}


@app.route("/inversiones", methods=["GET", "POST"])
@requiere
def inversiones():
    if request.method == "POST":
        c = _campos_propiedad()
        if not c["nombre"]:
            flash("Escribe el nombre de la propiedad.")
            return redirect(url_for("inversiones"))
        if c["valor_actual"] is None:
            c["valor_actual"] = c["costo"]
        cur = db().execute("INSERT INTO propiedades(nombre, tipo, ubicacion, costo, valor_actual, parte, socio, estado, notas, "
                           "fecha_compra, activa, alquiler, dia_pago) VALUES(?,?,?,?,?,?,?,?,?,?,1,0,1)",
                           tuple(c[k] for k in ("nombre", "tipo", "ubicacion", "costo", "valor_actual", "parte", "socio",
                                                "estado", "notas", "fecha_compra")))
        anotar(f"Agregaste la propiedad {c['nombre']}")
        db().commit()
        flash(f"{c['nombre']} agregada.")
        return redirect(url_for("ver_propiedad", pid=cur.lastrowid))
    lista, t = resumen_inversiones()
    return render_template("inversiones.html", lista=lista, t=t, tipos=TIPOS_PROP, estados=ESTADOS_PROP)


@app.route("/inversiones/<int:pid>", methods=["GET", "POST"])
@requiere
def ver_propiedad(pid):
    p = db().execute("SELECT * FROM propiedades WHERE id=? AND activa=1", (pid,)).fetchone() or abort(404)
    if request.method == "POST":
        acc = request.form.get("accion")
        if acc == "editar":
            c = _campos_propiedad()
            if c["nombre"]:
                if c["valor_actual"] is None:
                    c["valor_actual"] = c["costo"]
                db().execute("UPDATE propiedades SET nombre=?, tipo=?, ubicacion=?, costo=?, valor_actual=?, parte=?, socio=?, "
                             "estado=?, notas=?, fecha_compra=? WHERE id=?",
                             tuple(c[k] for k in ("nombre", "tipo", "ubicacion", "costo", "valor_actual", "parte", "socio",
                                                  "estado", "notas", "fecha_compra")) + (pid,))
                cambios = []
                if (p["valor_actual"] or 0) != (c["valor_actual"] or 0):
                    cambios.append(f"valor {dinero(p['valor_actual'] or 0)} → {dinero(c['valor_actual'])}")
                anotar(f"Editaste la propiedad {c['nombre']}" + (f" ({', '.join(cambios)})" if cambios else ""))
                flash("Guardado.")
        elif acc == "valor":
            v = num(request.form.get("valor_actual"))
            if v is None or v < 0:
                flash("Escribe cuánto vale hoy.")
            else:
                antes = p["valor_actual"] if p["valor_actual"] is not None else (p["costo"] or 0)
                db().execute("UPDATE propiedades SET valor_actual=? WHERE id=?", (v, pid))
                anotar(f"{p['nombre']}: valor {dinero(antes)} → {dinero(v)}")
                flash(f"Listo: {p['nombre']} vale {dinero(v)}.")
        elif acc == "fecha":
            fc = request.form.get("fecha_compra", "")
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", fc):
                db().execute("UPDATE propiedades SET fecha_compra=? WHERE id=?", (fc, pid))
                anotar(f"{p['nombre']}: fecha de compra {fc}")
                flash("Fecha de compra guardada.")
        elif acc == "borrar":
            db().execute("UPDATE propiedades SET activa=0 WHERE id=?", (pid,))
            db().execute("UPDATE contratos SET estado='terminado' WHERE propiedad_id=? AND estado='activo'", (pid,))
            anotar(f"Eliminaste la propiedad {p['nombre']}")
            db().commit()
            flash(f"{p['nombre']} eliminada. Sus movimientos viejos se quedan en tus meses.")
            return redirect(url_for("inversiones"))
        elif acc in ("contrato", "editar_contrato"):
            f = request.form
            dep_m = num(f.get("deposito_meses"))
            monto = num(f.get("monto")) or 0
            vals = {"unidad": f.get("unidad", "").strip()[:60], "inquilino": f.get("inquilino", "").strip()[:80],
                    "telefono": f.get("telefono", "").strip()[:40], "correo": f.get("correo", "").strip()[:120],
                    "documento": f.get("documento", "").strip()[:40], "inicio": f.get("inicio") or None,
                    "fin": f.get("fin") or None, "monto": monto,
                    "dia_pago": max(1, min(31, f.get("dia_pago", type=int) or 1)), "deposito_meses": dep_m,
                    "deposito_recibido": num(f.get("deposito_recibido")) if f.get("deposito_recibido") else (round(dep_m * monto, 2) if dep_m else None),
                    "deposito_devolver": num(f.get("deposito_devolver")), "notas": f.get("notas", "").strip()[:500]}
            if vals["deposito_devolver"] is None:
                vals["deposito_devolver"] = vals["deposito_recibido"]
            if vals["inicio"] and vals["fin"] and vals["fin"] < vals["inicio"]:
                flash("La fecha de fin es antes del inicio. Revísala.")
                return redirect(url_for("ver_propiedad", pid=pid) + "#contratos")
            cols = list(vals)
            if acc == "contrato":
                cur = db().execute(f"INSERT INTO contratos(propiedad_id, {', '.join(cols)}, estado) VALUES(?, {', '.join('?' * len(cols))}, 'activo')",
                                   (pid,) + tuple(vals.values()))
                cid = cur.lastrowid
                if p["estado"] in (None, "", "Vacía"):
                    db().execute("UPDATE propiedades SET estado='Alquilada' WHERE id=?", (pid,))
                anotar(f"Nuevo contrato en {p['nombre']}: {vals['inquilino'] or 'inquilino'} {dinero(monto)} al mes")
                flash("Contrato agregado. El alquiler te va a salir cada mes para confirmarlo.")
            else:
                cid = f.get("cid", type=int)
                db().execute(f"UPDATE contratos SET {', '.join(c + '=?' for c in cols)} WHERE id=? AND propiedad_id=?",
                             tuple(vals.values()) + (cid, pid))
                anotar(f"Editaste un contrato de {p['nombre']}")
                flash("Contrato guardado.")
            guardar_archivo_contrato(request.files.get("archivo"), cid)
        elif acc == "terminar":
            cid = request.form.get("cid", type=int)
            dev = num(request.form.get("deposito_devuelto"))
            db().execute("UPDATE contratos SET estado='terminado', fecha_salida=?, deposito_devuelto=? WHERE id=? AND propiedad_id=?",
                         (request.form.get("fecha_salida") or date.today().isoformat(), dev, cid, pid))
            if not db().execute("SELECT 1 FROM contratos WHERE propiedad_id=? AND estado='activo'", (pid,)).fetchone() \
                    and p["estado"] == "Alquilada":
                db().execute("UPDATE propiedades SET estado='Vacía' WHERE id=?", (pid,))
            anotar(f"Terminaste un contrato de {p['nombre']}" + (f" (depósito devuelto {dinero(dev)})" if dev else ""))
            flash("Contrato terminado. Queda guardado en el historial.")
        elif acc == "documento":
            tipo = request.form.get("tipo") if request.form.get("tipo") in TIPOS_DOC else "Otro"
            nota = request.form.get("nota", "").strip()[:300]
            fdoc = request.form.get("fecha") if re.fullmatch(r"\d{4}-\d{2}-\d{2}", request.form.get("fecha", "")) else None
            n, malos = 0, 0
            os.makedirs(RECIBOS, exist_ok=True)
            for arch in request.files.getlist("archivos"):
                if not arch or not arch.filename:
                    continue
                ext = os.path.splitext(arch.filename)[1].lower()
                if ext not in EXT_DOC:
                    malos += 1
                    continue
                nombre_arch = f"doc-{pid}-{secrets.token_hex(6)}{ext}"
                arch.save(os.path.join(RECIBOS, nombre_arch))
                titulo = (request.form.get("nombre", "").strip() or os.path.splitext(os.path.basename(arch.filename))[0])[:100]
                db().execute("INSERT INTO documentos(propiedad_id, tipo, nombre, nota, fecha, archivo, subido) VALUES(?,?,?,?,?,?,?)",
                             (pid, tipo, titulo, nota, fdoc, nombre_arch, datetime.now().strftime("%Y-%m-%d %H:%M")))
                n += 1
            if n:
                anotar(f"{p['nombre']}: subiste {n} documento{'s' if n > 1 else ''} ({tipo})")
                flash(f"Listo: {n} documento{'s' if n > 1 else ''} guardado{'s' if n > 1 else ''}."
                      + (f" {malos} no se subió porque no es PDF ni foto." if malos else ""))
            else:
                flash("Elige un PDF o una foto para subir." if not malos else "Solo se pueden subir PDF o fotos.")
        elif acc == "borrar_documento":
            d = db().execute("SELECT * FROM documentos WHERE id=? AND propiedad_id=?",
                             (request.form.get("did", type=int), pid)).fetchone()
            if d:
                borrar_recibo(d["archivo"])
                db().execute("DELETE FROM documentos WHERE id=?", (d["id"],))
                anotar(f"{p['nombre']}: borraste el documento «{d['nombre']}»")
                flash("Documento borrado.")
        elif acc == "borrar_contrato":
            cid = request.form.get("cid", type=int)
            db().execute("DELETE FROM contratos WHERE id=? AND propiedad_id=?", (cid, pid))
            anotar(f"Borraste un contrato de {p['nombre']}")
        db().commit()
        return redirect(url_for("ver_propiedad", pid=pid) + ("#contratos" if "contrato" in (acc or "") or acc == "terminar"
                                                              else "#documentos" if "documento" in (acc or "") else ""))
    anio = request.args.get("anio", type=int) or date.today().year
    x = datos_propiedad(p, anio)
    contratos = db().execute("SELECT * FROM contratos WHERE propiedad_id=? ORDER BY estado='activo' DESC, inicio DESC", (pid,)).fetchall()
    gastos = db().execute("SELECT * FROM movimientos WHERE propiedad_id=? AND tipo='gasto' ORDER BY fecha DESC, id DESC LIMIT 60",
                          (pid,)).fetchall()
    cobros = db().execute("SELECT * FROM movimientos WHERE propiedad_id=? AND tipo='ingreso' ORDER BY fecha DESC, id DESC LIMIT 24",
                          (pid,)).fetchall()
    # meses del año: cobrado o no
    meses = []
    desde = creado_desde()
    for m in range(1, 13):
        ini, fin = date(anio, m, 1).isoformat(), fecha_en_mes(anio, m, 31).isoformat()
        cob = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE propiedad_id=? AND tipo='ingreso' "
                           "AND fecha BETWEEN ? AND ?", (pid, ini, fin)).fetchone()[0]
        toca = any((not c["inicio"] or fin >= c["inicio"]) and (not c["fin"] or ini <= c["fin"]) for c in x["activos"])
        vencido = fecha_en_mes(anio, m, 28) < date.today() if toca else False
        futuro = date(anio, m, 1) > date.today()
        meses.append({"mes": MESES[m - 1][:3], "cobrado": cob,
                      "estado": "ok" if cob else ("" if not toca or futuro or date(anio, m, 1) < desde else ("mal" if vencido else "pend"))})
    return render_template("propiedad.html", x=x, p=p, contratos=contratos, gastos=gastos, cobros=cobros, meses=meses, anio=anio,
                           tipos=TIPOS_PROP, estados=ESTADOS_PROP, hoy=date.today().isoformat(), tipos_doc=TIPOS_DOC,
                           documentos=db().execute("SELECT * FROM documentos WHERE propiedad_id=? ORDER BY COALESCE(fecha, subido) DESC, id DESC",
                                                   (pid,)).fetchall())


@app.route("/documento/<int:did>")
@requiere
def ver_documento(did):
    d = db().execute("SELECT * FROM documentos WHERE id=?", (did,)).fetchone()
    if not d or not os.path.exists(os.path.join(RECIBOS, os.path.basename(d["archivo"]))):
        abort(404)
    ext = os.path.splitext(d["archivo"])[1]
    return send_file(os.path.join(RECIBOS, os.path.basename(d["archivo"])),
                     download_name=re.sub(r"[^\w\- ]", "", d["nombre"] or "documento").strip()[:80] + ext)


def guardar_archivo_contrato(archivo, cid):
    if not archivo or not archivo.filename:
        return
    ext = os.path.splitext(archivo.filename)[1].lower()
    if ext not in (".pdf", ".jpg", ".jpeg", ".png", ".heic", ".webp"):
        flash("El contrato debe ser PDF o foto.")
        return
    os.makedirs(RECIBOS, exist_ok=True)
    viejo = db().execute("SELECT archivo FROM contratos WHERE id=?", (cid,)).fetchone()
    if viejo and viejo[0]:
        borrar_recibo(viejo[0])
    nombre = f"contrato-{cid}-{secrets.token_hex(4)}{ext}"
    archivo.save(os.path.join(RECIBOS, nombre))
    db().execute("UPDATE contratos SET archivo=? WHERE id=?", (nombre, cid))


@app.route("/contrato/<int:cid>/archivo")
@requiere
def archivo_contrato(cid):
    c = db().execute("SELECT archivo FROM contratos WHERE id=?", (cid,)).fetchone()
    if not c or not c[0] or not os.path.exists(os.path.join(RECIBOS, os.path.basename(c[0]))):
        abort(404)
    return send_file(os.path.join(RECIBOS, os.path.basename(c[0])))


@app.route("/deudas", methods=["GET", "POST"])
@requiere
def deudas():
    if request.method == "POST":
        acc = request.form.get("accion")
        did = request.form.get("id", type=int)
        d = db().execute("SELECT * FROM deudas WHERE id=?", (did,)).fetchone() if did else None
        if acc == "abonar" and d:
            m = num(request.form.get("monto"))
            if not m or m <= 0:
                flash("Escribe cuánto abonaste.")
            else:
                fe = request.form.get("fecha") or date.today().isoformat()
                db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, deuda_id) VALUES('gasto',?,?,?,?,?)",
                             (fe, m, "Tarjetas y deudas", f"Abono {d['nombre']}", d["id"]))
                anotar(f"Abonaste ${m:,.2f} a {d['nombre']}")
                flash(f"Abono de ${m:,.2f} a {d['nombre']} anotado.")
                if request.form.get("cierre"):
                    ajuste(f"cierre_{request.form['cierre'][:7]}", "hecho")
        elif acc == "editar" and d:
            interes = num(request.form.get("interes"))
            abonado_antes = num(request.form.get("abonado_antes")) or 0
            saldo_ini = num(request.form.get("saldo_inicial")) or 0
            # "Lo que debes hoy": si lo cambiaste, se ajusta el saldo inicial y se respeta todo lo abonado
            hoy_nuevo, hoy_antes = num(request.form.get("saldo_hoy")), num(request.form.get("saldo_hoy_antes"))
            cambio_saldo = ""
            if hoy_nuevo is not None and hoy_nuevo >= 0 and (hoy_antes is None or abs(hoy_nuevo - hoy_antes) >= 0.005):
                abonos = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE deuda_id=?", (did,)).fetchone()[0]
                saldo_ini = round(hoy_nuevo + abonado_antes + abonos, 2)
                cambio_saldo = f" (ahora debes {dinero(hoy_nuevo)}" + (f", antes {dinero(hoy_antes)})" if hoy_antes is not None else ")")
            db().execute("UPDATE deudas SET nombre=?, categoria=?, saldo_inicial=?, abonado_antes=?, interes=?, minimo=? WHERE id=?",
                         (request.form.get("nombre", d["nombre"]).strip()[:80] or d["nombre"], request.form.get("categoria"),
                          saldo_ini, abonado_antes,
                          None if interes is None else max(0, min(99, interes)), num(request.form.get("minimo")), did))
            anotar(f"Editaste la deuda {d['nombre']}{cambio_saldo}")
            flash(f"{d['nombre']} guardada." + (f" Ahora debes {dinero(hoy_nuevo)}." if cambio_saldo else ""))
        elif acc == "borrar_abono" and d:
            m = db().execute("SELECT * FROM movimientos WHERE id=? AND deuda_id=?", (request.form.get("mid", type=int), did)).fetchone()
            if m:
                db().execute("DELETE FROM movimientos WHERE id=?", (m["id"],))
                anotar(f"Borraste un abono de {dinero(m['monto'])} a {d['nombre']} del {m['fecha']}")
                flash(f"Abono de {dinero(m['monto'])} borrado. La deuda volvió a subir.")
        elif acc == "agendar":
            fe = request.form.get("fecha_ag", "")
            m = num(request.form.get("monto_ag")) or 0
            dd = db().execute("SELECT * FROM deudas WHERE id=?", (request.form.get("deuda_ag", type=int),)).fetchone()
            nombre = dd["nombre"] if dd else request.form.get("nombre_ag", "").strip()[:80]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fe) or not nombre:
                flash("Escoge la fecha y qué cuenta vas a pagar.")
            else:
                db().execute("INSERT INTO agenda(deuda_id, nombre, monto, fecha, nota, mensual, creado) VALUES(?,?,?,?,?,?,?)",
                             (dd["id"] if dd else None, nombre, m, fe, request.form.get("nota_ag", "").strip()[:200],
                              1 if request.form.get("mensual_ag") else 0, datetime.now().strftime("%Y-%m-%d %H:%M")))
                anotar(f"Agendaste pagar {nombre} {dinero(m)} el {fe}")
                flash(f"Agendado: {nombre} el {fecha(fe)}. Toca 📅 para ponerlo en el calendario de tu teléfono con alarma.")
            db().commit()
            return redirect(url_for("deudas") + "#agenda")
        elif acc in ("agenda_pagado", "agenda_quitar"):
            ag = db().execute("SELECT * FROM agenda WHERE id=? AND estado='pendiente'", (request.form.get("aid", type=int),)).fetchone()
            if ag and acc == "agenda_quitar":
                db().execute("UPDATE agenda SET estado='cancelado' WHERE id=?", (ag["id"],))
                anotar(f"Quitaste el pago agendado de {ag['nombre']} ({ag['fecha']})")
                flash("Pago agendado quitado.")
            elif ag:
                monto = num(request.form.get("monto_real")) or ag["monto"] or 0
                mov = None
                dd = db().execute("SELECT * FROM deudas WHERE id=? AND activa=1", (ag["deuda_id"],)).fetchone() if ag["deuda_id"] else None
                if dd and monto > 0:
                    mov = db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, deuda_id) VALUES('gasto',?,?,?,?,?)",
                                       (date.today().isoformat(), monto, "Tarjetas y deudas", f"Abono {dd['nombre']}", dd["id"])).lastrowid
                db().execute("UPDATE agenda SET estado='pagado', mov_id=?, monto=? WHERE id=?", (mov, monto, ag["id"]))
                sig = ""
                if ag["mensual"]:
                    f0 = date.fromisoformat(ag["fecha"])
                    nm = (f0.replace(day=1) + timedelta(days=32)).replace(day=1)
                    nueva = fecha_en_mes(nm.year, nm.month, f0.day)
                    db().execute("INSERT INTO agenda(deuda_id, nombre, monto, fecha, nota, mensual, creado) VALUES(?,?,?,?,?,1,?)",
                                 (ag["deuda_id"], ag["nombre"], ag["monto"], nueva.isoformat(), ag["nota"],
                                  datetime.now().strftime("%Y-%m-%d %H:%M")))
                    sig = f" El próximo quedó para el {fecha(nueva)}."
                anotar(f"Pagaste lo agendado: {ag['nombre']} {dinero(monto)}")
                flash((f"Listo: abono de {dinero(monto)} a {ag['nombre']} anotado." if mov else f"Listo: {ag['nombre']} marcado como pagado.") + sig)
            db().commit()
            return redirect(url_for("deudas") + "#agenda")
        elif acc == "plan":
            p = num(request.form.get("plan_mensual"))
            ajuste("plan_mensual", p if p and p > 0 else "")
            ajuste("plan_metodo", "bola" if request.form.get("metodo") == "bola" else "avalancha")
            anotar(f"Pusiste tu plan de deudas: {dinero(p or 0)} al mes")
            db().commit()
            return redirect(url_for("deudas") + "#plan")
        elif acc == "pagada" and d:
            db().execute("UPDATE deudas SET activa=0 WHERE id=?", (did,))
            anotar(f"Quitaste la deuda {d['nombre']} de la lista")
        elif acc == "agregar":
            n = request.form.get("nombre", "").strip()[:80]
            if n:
                db().execute("INSERT INTO deudas(nombre, categoria, saldo_inicial, abonado_antes) VALUES(?,?,?,?)",
                             (n, request.form.get("categoria"), num(request.form.get("saldo_inicial")) or 0, 0))
                anotar(f"Agregaste la deuda {n}")
        db().commit()
        volver = request.form.get("volver", "")
        return redirect(volver if volver.startswith("/") and not volver.startswith("//") else url_for("deudas"))
    lista = estado_deudas()
    plan = num(ajuste("plan_mensual", defecto="")) or 0
    metodo = ajuste("plan_metodo", defecto="avalancha")
    sims = {}
    if plan:
        sims = {m: simular_deudas(lista, plan, m) for m in ("avalancha", "bola")}
    sin_interes = [x["d"]["nombre"] for x in lista if x["saldo"] > 0 and x["d"]["categoria"] == "Tarjeta de crédito"
                   and x["d"]["interes"] is None]
    minimos = sum(x["d"]["minimo"] or 0 for x in lista if x["saldo"] > 0)
    objetivo = objetivo_deuda(lista)
    tot_ini = sum(x["d"]["saldo_inicial"] or 0 for x in lista)
    tot_ab = sum(x["abonado"] for x in lista)
    tot_saldo = sum(x["saldo"] for x in lista)
    # ritmo: lo abonado en los últimos 90 días, para estimar cuándo terminas
    hace90 = (date.today() - timedelta(days=90)).isoformat()
    ritmo = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE deuda_id IS NOT NULL AND fecha>=?",
                         (hace90,)).fetchone()[0] / 3
    primero = db().execute("SELECT MIN(fecha) FROM movimientos WHERE deuda_id IS NOT NULL").fetchone()[0]
    con_historia = primero and (date.today() - date.fromisoformat(primero)).days >= 60
    meses_faltan = (tot_saldo / ritmo) if (ritmo > 0 and con_historia) else None
    return render_template("deudas.html", lista=lista, tot_ini=tot_ini, tot_ab=tot_ab, tot_saldo=tot_saldo,
                           pct=(tot_ab / tot_ini * 100) if tot_ini else 0, ritmo=ritmo, meses_faltan=meses_faltan,
                           cat_deuda=CAT_DEUDA, hoy=date.today().isoformat(), objetivo=objetivo,
                           plan=plan, metodo=metodo, sims=sims, sin_interes=sin_interes, minimos=minimos,
                           agenda=db().execute("SELECT * FROM agenda WHERE estado='pendiente' ORDER BY fecha, id").fetchall(),
                           agenda_hecha=db().execute("SELECT * FROM agenda WHERE estado='pagado' ORDER BY fecha DESC, id DESC LIMIT 10").fetchall())


@app.route("/agenda/<int:aid>.ics")
@requiere
def agenda_ics(aid):
    """Archivo de calendario para meter el pago al calendario del teléfono, con alarma."""
    ag = db().execute("SELECT * FROM agenda WHERE id=?", (aid,)).fetchone()
    if not ag:
        abort(404)
    def esc(s):
        return str(s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    f = ag["fecha"].replace("-", "")
    titulo = f"Pagar {ag['nombre']}" + (f" {dinero(ag['monto'])}" if ag["monto"] else "")
    lineas = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Mis finanzas//ES", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
              "BEGIN:VEVENT", f"UID:agenda-{ag['id']}@mis-finanzas", f"DTSTAMP:{datetime.utcnow():%Y%m%dT%H%M%SZ}",
              f"DTSTART:{f}T090000", f"DTEND:{f}T093000", f"SUMMARY:{esc(titulo)}",
              f"DESCRIPTION:{esc((ag['nota'] or '') + chr(10) + 'Márcalo como pagado en Mis finanzas → Deudas.')}"]
    if ag["mensual"]:
        lineas.append("RRULE:FREQ=MONTHLY")
    lineas += ["BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{esc(titulo)}", "TRIGGER:-P1D", "END:VALARM",
               "BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{esc(titulo)}", "TRIGGER:PT0M", "END:VALARM",
               "END:VEVENT", "END:VCALENDAR"]
    return app.response_class("\r\n".join(lineas) + "\r\n", mimetype="text/calendar",
                              headers={"Content-Disposition": f'inline; filename="pago-{ag["id"]}.ics"'})


@app.route("/ahorros", methods=["GET", "POST"])
@requiere
def ahorros():
    if request.method == "POST":
        acc = request.form.get("accion")
        aid = request.form.get("id", type=int)
        a = db().execute("SELECT * FROM ahorros WHERE id=?", (aid,)).fetchone() if aid else None
        m = num(request.form.get("monto"))
        hoy = date.today().isoformat()
        fe = request.form.get("fecha", "")
        if acc == "apartar" and re.fullmatch(r"\d{4}-\d{2}-\d{2}", fe) and fe <= hoy:
            hoy = fe  # desde el cierre: cuenta en el mes que cerró
        if acc in ("apartar", "sacar", "irs") and a:
            if not m or m <= 0:
                flash("Escribe el monto.")
            elif acc == "apartar":
                db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, ahorro_id) VALUES('ahorro',?,?,?,?,?)",
                             (hoy, m, "Ahorro", f"Apartado para {a['nombre']}", a["id"]))
                anotar(f"Apartaste {dinero(m)} para {a['nombre']}")
                flash(f"Apartaste {dinero(m)} para {a['nombre']}.")
                if request.form.get("cierre"):
                    ajuste(f"cierre_{request.form['cierre'][:7]}", "hecho")
            else:
                saldo = db().execute("SELECT COALESCE(SUM(monto),0) FROM movimientos WHERE ahorro_id=?", (a["id"],)).fetchone()[0]
                if m > saldo + 0.005:
                    flash(f"En {a['nombre']} solo tienes {dinero(saldo)}.")
                else:
                    motivo = request.form.get("nota", "").strip()[:80]
                    db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, ahorro_id) VALUES('ahorro',?,?,?,?,?)",
                                 (hoy, -m, "Ahorro", f"Sacaste de {a['nombre']}" + (f": {motivo}" if motivo else ""), a["id"]))
                    if acc == "irs":
                        db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota) VALUES('gasto',?,?,?,?)",
                                     (hoy, m, "Impuestos", "Pago estimado al IRS"))
                        anotar(f"Pagaste {dinero(m)} al IRS (de lo apartado)")
                        flash(f"Pago de {dinero(m)} al IRS anotado. Salió de lo que tenías apartado.")
                    else:
                        anotar(f"Sacaste {dinero(m)} de {a['nombre']}" + (f" ({motivo})" if motivo else ""))
                        flash(f"Sacaste {dinero(m)} de {a['nombre']}. Vuelve a contar como dinero del mes.")
        elif acc == "meta" and a:
            db().execute("UPDATE ahorros SET nombre=?, meta=? WHERE id=?",
                         (request.form.get("nombre", "").strip()[:60] or a["nombre"], m if m and m > 0 else None, a["id"]))
            anotar(f"Cambiaste la meta de {a['nombre']}")
        elif acc == "quitar" and a and a["tipo"] == "meta":
            db().execute("UPDATE ahorros SET activo=0 WHERE id=?", (a["id"],))
            anotar(f"Quitaste el ahorro {a['nombre']}")
        elif acc == "nuevo":
            n = request.form.get("nombre", "").strip()[:60]
            if n:
                db().execute("INSERT INTO ahorros(nombre, tipo, meta) VALUES(?, 'meta', ?)", (n, m if m and m > 0 else None))
                anotar(f"Creaste el ahorro {n}")
        elif acc == "pct":
            p = num(request.form.get("pct"))
            if p is not None and 0 <= p <= 60:
                ajuste("pct_impuestos", p)
            ajuste("cats_impuestos", json.dumps([c for c in request.form.getlist("cats") if c in CAT_INGRESO]))
            anotar(f"Impuestos: apartar {p:g}% de {', '.join(request.form.getlist('cats')) or 'nada'}")
            flash("Guardado.")
        db().commit()
        volver = request.form.get("volver", "")
        return redirect(volver if volver.startswith("/") and not volver.startswith("//") else url_for("ahorros"))
    lista, gasto_mes = estado_ahorros()
    hoy = date.today()
    r = resumen_mes(hoy.year, hoy.month)
    # lo que tocaba apartar este año vs lo apartado
    gravable_anio = sum(resumen_mes(hoy.year, m)["gravable"] for m in range(1, hoy.month + 1))
    irs = proxima_fecha_irs()
    movs = db().execute("SELECT m.*, a.nombre an FROM movimientos m JOIN ahorros a ON a.id=m.ahorro_id "
                        "ORDER BY m.fecha DESC, m.id DESC LIMIT 15").fetchall()
    return render_template("ahorros.html", lista=lista, gasto_mes=gasto_mes, r=r, pct=pct_impuestos(),
                           cats=cats_impuestos(), cat_ingreso=CAT_INGRESO, irs=irs, movs=movs,
                           gravable_anio=gravable_anio)


@app.route("/cierre")
@requiere
def cierre():
    hoy = date.today()
    pasado = hoy.replace(day=1) - timedelta(days=1)
    anio, mes = mes_param() if request.args.get("mes") else (pasado.year, pasado.month)
    r = resumen_mes(anio, mes)
    ant = date(anio, mes, 1) - timedelta(days=1)
    ra = resumen_mes(ant.year, ant.month)
    lista = estado_deudas()
    obj = objetivo_deuda(lista)
    emerg = db().execute("SELECT id FROM ahorros WHERE tipo='emergencia' AND activo=1").fetchone()
    comparar = []
    for c, v in r["porcat"].items():
        antes = ra["porcat"].get(c, 0)
        comparar.append({"cat": c, "ahora": v, "antes": antes, "dif": v - antes})
    return render_template("cierre.html", r=r, ra=ra, anio=anio, mes=mes, nombre_mes=MESES[mes - 1],
                           nombre_ant=MESES[ant.month - 1], limites=estado_limites(r["porcat"], anio, mes),
                           obj=obj, deudas=[x for x in lista if x["saldo"] > 0], emerg=emerg[0] if emerg else None,
                           comparar=comparar, clave=f"{anio}-{mes:02d}", hecho=ajuste(f"cierre_{anio}-{mes:02d}"),
                           hoy=min(hoy, fecha_en_mes(anio, mes, 31)).isoformat())


@app.post("/cierre/listo")
@requiere
def cierre_listo():
    m = request.form.get("mes", "")[:7]
    if re.fullmatch(r"\d{4}-\d{2}", m):
        ajuste(f"cierre_{m}", "hecho"); db().commit()
    return redirect(url_for("inicio"))


@app.route("/recibo/<int:mid>")
@requiere
def ver_recibo(mid):
    m = db().execute("SELECT recibo FROM movimientos WHERE id=?", (mid,)).fetchone()
    if not m or not m[0]:
        abort(404)
    ruta = os.path.join(RECIBOS, os.path.basename(m[0]))
    if not os.path.exists(ruta):
        abort(404)
    return send_file(ruta)


@app.route("/ajustes", methods=["GET", "POST"])
@requiere
def ajustes():
    if request.method == "POST":
        acc = request.form.get("accion")
        if acc == "limites":
            for c in CAT_GASTO:
                v = num(request.form.get(f"lim_{c}"))
                if v and v > 0:
                    db().execute("INSERT INTO limites(categoria, monto) VALUES(?,?) ON CONFLICT(categoria) DO UPDATE SET monto=excluded.monto", (c, v))
                else:
                    db().execute("DELETE FROM limites WHERE categoria=?", (c,))
            anotar("Cambiaste tus límites por categoría")
            flash("Límites guardados.")
        elif acc == "enlace":
            codigo = request.form.get("codigo", "").strip()
            if not codigo:
                db().execute("DELETE FROM ajustes WHERE clave='enlace'")
                anotar("Quitaste el enlace con el portal de la compañía")
                flash("Enlace quitado.")
            elif not re.fullmatch(r"https?://[^\s|]+\|[A-Za-z0-9_\-]{20,}", codigo):
                flash("Ese código no se ve bien. Cópialo completo del portal de la compañía (Ganancias → Enlace).")
            else:
                antes = ajuste("enlace")
                ajuste("enlace", codigo); db().commit()
                n, err = sincronizar_portal(db())
                if err:
                    if antes: ajuste("enlace", antes)
                    else: db().execute("DELETE FROM ajustes WHERE clave='enlace'")
                    flash(err)
                else:
                    anotar("Enlazaste el portal de la compañía")
                    flash(f"¡Enlazado! Traje {n} quincena{'s' if n != 1 else ''} del portal.")
        elif acc == "sync":
            n, err = sincronizar_portal(db())
            flash(err or (f"Listo: {n} cambio{'s' if n != 1 else ''} del portal." if n else "Todo al día, no hay nada nuevo."))
        elif acc == "bloqueo":
            si = request.form.get("bloqueo") == "1" and hay_llaves()
            ajuste("bloqueo", "1" if si else "0")
            anotar("Activaste pedir Face ID al abrir la app" if si else "Quitaste pedir Face ID al abrir la app")
            flash(f"Listo: te pedirá Face ID cada vez que abras la app (después de {BLOQUEO_MIN} minutos sin usarla)."
                  if si else "Listo: ya no te pedirá Face ID al abrir la app.")
        elif acc == "quitar_llave":
            r = db().execute("SELECT nombre FROM llaves WHERE id=?", (request.form.get("id"),)).fetchone()
            if r:
                db().execute("DELETE FROM llaves WHERE id=?", (request.form.get("id"),))
                anotar(f"Quitaste Face ID de «{r['nombre']}»")
                flash("Face ID quitado de ese teléfono.")
        db().commit()
        return redirect(url_for("ajustes"))
    lim = {l["categoria"]: l["monto"] for l in db().execute("SELECT * FROM limites")}
    hoy = date.today()
    _, _, _, porcat = totales_mes(hoy.year, hoy.month)
    # lo que gastaste en promedio los últimos 3 meses, para ayudarte a poner límites
    prom, d = {}, hoy.replace(day=1)
    for _ in range(3):
        d = (d - timedelta(days=1)).replace(day=1)
        for c, v in totales_mes(d.year, d.month)[3].items():
            prom[c] = prom.get(c, 0) + v / 3
    enlace = ajuste("enlace")
    return render_template("ajustes.html", lim=lim, cats=[c for c in CAT_GASTO if c not in ("Tarjetas y deudas", "Impuestos")],
                           prom=prom, iconos=ICONOS, enlace=enlace.split("|")[0] if enlace else None,
                           ultima_sync=ajuste("ultima_sync"),
                           llaves=db().execute("SELECT * FROM llaves ORDER BY id").fetchall(),
                           bloqueo=ajuste("bloqueo") == "1", bloqueo_min=BLOQUEO_MIN)


@app.route("/me-deben", methods=["GET", "POST"])
@requiere
def me_deben():
    if request.method == "POST":
        acc = request.form.get("accion")
        did = request.form.get("id", type=int)
        d = db().execute("SELECT * FROM por_cobrar WHERE id=?", (did,)).fetchone() if did else None
        f = request.form
        if acc == "cobrar" and d:
            m = num(f.get("monto"))
            if not m or m <= 0:
                flash("Escribe cuánto te pagaron.")
            else:
                fe = f.get("fecha") or date.today().isoformat()
                db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, cobro_id) VALUES('ingreso',?,?,?,?,?)",
                             (fe, m, "Me pagaron lo que me debían", f"Pago de {d['persona']}", d["id"]))
                anotar(f"{d['persona']} te pagó {dinero(m)}")
                saldo = next((x["saldo"] for x in estado_por_cobrar() if x["d"]["id"] == d["id"]), 0)
                flash(f"Anotado: {d['persona']} te pagó {dinero(m)}. " + (f"Todavía te debe {dinero(saldo)}." if saldo > 0 else "¡Ya te pagó todo!"))
        elif acc == "agregar":
            persona = f.get("persona", "").strip()[:80]
            monto = num(f.get("monto")) or 0
            if not persona or monto <= 0:
                flash("Escribe quién te debe y cuánto.")
            else:
                fe = f.get("fecha") or date.today().isoformat()
                cur = db().execute("INSERT INTO por_cobrar(persona, concepto, monto, cobrado_antes, fecha, vence, telefono, notas) "
                                   "VALUES(?,?,?,?,?,?,?,?)", (persona, f.get("concepto", "").strip()[:120], monto,
                                                               num(f.get("cobrado_antes")) or 0, fe, f.get("vence") or None,
                                                               f.get("telefono", "").strip()[:40], f.get("notas", "").strip()[:500]))
                if f.get("salio"):  # se lo prestaste ahora: sale de tu dinero del mes
                    db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, cobro_id) VALUES('gasto',?,?,?,?,?)",
                                 (fe, monto, "Préstamos que hice", f"Préstamo a {persona}", cur.lastrowid))
                anotar(f"{persona} te debe {dinero(monto)}")
                flash(f"Anotado: {persona} te debe {dinero(monto)}.")
        elif acc == "editar" and d:
            db().execute("UPDATE por_cobrar SET persona=?, concepto=?, monto=?, cobrado_antes=?, fecha=?, vence=?, telefono=?, notas=? WHERE id=?",
                         (f.get("persona", d["persona"]).strip()[:80] or d["persona"], f.get("concepto", "").strip()[:120],
                          num(f.get("monto")) or 0, num(f.get("cobrado_antes")) or 0, f.get("fecha") or None,
                          f.get("vence") or None, f.get("telefono", "").strip()[:40], f.get("notas", "").strip()[:500], d["id"]))
            anotar(f"Editaste lo que te debe {d['persona']}")
            flash("Guardado.")
        elif acc == "quitar" and d:
            db().execute("UPDATE por_cobrar SET activa=0 WHERE id=?", (d["id"],))
            anotar(f"Quitaste de la lista lo que te debía {d['persona']}")
        db().commit()
        return redirect(url_for("me_deben"))
    lista = estado_por_cobrar()
    total = sum(x["d"]["monto"] or 0 for x in lista)
    cobrado = sum(x["cobrado"] for x in lista)
    pagos = db().execute("SELECT m.*, p.persona FROM movimientos m JOIN por_cobrar p ON p.id=m.cobro_id "
                         "WHERE m.tipo='ingreso' ORDER BY m.fecha DESC, m.id DESC LIMIT 15").fetchall()
    return render_template("me_deben.html", lista=lista, total=total, cobrado=cobrado,
                           saldo=sum(x["saldo"] for x in lista), hoy=date.today().isoformat(), pagos=pagos)


@app.route("/anio")
@requiere
def ver_anio():
    anio = request.args.get("anio", type=int) or date.today().year
    meses, tot_i, tot_g, tot_a, cats = [], 0, 0, 0, {}
    for m in range(1, 13):
        r = resumen_mes(anio, m)
        i, gg, pc = r["ing"], r["gas"], r["porcat"]
        meses.append({"nombre": MESES[m - 1].capitalize(), "mes": f"{anio}-{m:02d}", "ing": i, "gas": gg,
                      "queda": i - gg, "aho": r["aho"], "extras": r["extras"]})
        tot_i += i; tot_g += gg; tot_a += r["aho"]
        for k, v in pc.items(): cats[k] = cats.get(k, 0) + v
    return render_template("anio.html", anio=anio, meses=meses, tot_i=tot_i, tot_g=tot_g, tot_a=tot_a,
                           tot_extras=sum(m["extras"] for m in meses),
                           cats=dict(sorted(cats.items(), key=lambda x: -x[1])))


@app.route("/anio/excel")
@requiere
def excel_anio():
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    anio = request.args.get("anio", type=int) or date.today().year
    props = propiedades()
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Movimientos"
    ws.append(["Fecha", "Tipo", "Categoría", "Detalle", "Propiedad", "Monto", "Tu parte"])
    for m in db().execute("SELECT * FROM movimientos WHERE substr(fecha,1,4)=? ORDER BY fecha", (str(anio),)):
        ws.append([m["fecha"], {"ahorro": "apartado"}.get(m["tipo"], m["tipo"]), m["categoria"], m["nota"],
                   props[m["propiedad_id"]]["nombre"] if m["propiedad_id"] in props else "", m["monto"], mi_monto(m, props)])
    r = wb.create_sheet("Meses"); r.append(["Mes", "Te entró", "Gastaste", "Te quedó", "Apartaste"])
    for mm in range(1, 13):
        rm = resumen_mes(anio, mm)
        r.append([MESES[mm - 1].capitalize(), rm["ing"], rm["gas"], round(rm["ing"] - rm["gas"], 2), rm["aho"]])
    ah = wb.create_sheet("Ahorros"); ah.append(["Ahorro", "Tienes", "Meta"])
    for x in estado_ahorros()[0]:
        ah.append([x["a"]["nombre"], x["saldo"], x["meta"] or ""])
    for col in "BC":
        for c in ah[col][1:]: c.number_format = '"$"#,##0.00'
    dd = wb.create_sheet("Deudas"); dd.append(["Deuda", "Categoría", "Saldo inicial", "Abonado", "Saldo actual", "% pagado"])
    for x in estado_deudas():
        dd.append([x["d"]["nombre"], x["d"]["categoria"], x["d"]["saldo_inicial"], round(x["abonado"], 2),
                   round(x["saldo"], 2), round(x["pct"], 1)])
    for col in "CDE":
        for c in dd[col][1:]: c.number_format = '"$"#,##0.00'
    iv = wb.create_sheet("Inversiones")
    iv.append(["Propiedad", "Tipo", "Estado", "Comprada", "Tu parte %", "Costó", "Vale hoy", "Plusvalía", "Alquiler al mes",
               f"Cobrado {anio}", f"Gastos {anio}", "Te tocó neto"])
    for x in resumen_inversiones()[0]:
        iv.append([x["p"]["nombre"], x["p"]["tipo"], x["estado"], x["p"]["fecha_compra"] or "", x["p"]["parte"], x["costo"], x["valor"], x["plusvalia"],
                   x["renta"], x["cob_anio"], x["gas_anio"], round(x["neto_anio_tuyo"], 2)])
    for col in "FGHIJKL":
        for c in iv[col][1:]: c.number_format = '"$"#,##0.00'
    md = wb.create_sheet("Me deben")
    md.append(["Persona", "Por qué", "Desde", "Quedó en pagar", "Te debía", "Te ha pagado", "Te debe"])
    for x in estado_por_cobrar(todas=True):
        md.append([x["d"]["persona"], x["d"]["concepto"], x["d"]["fecha"], x["d"]["vence"], x["d"]["monto"],
                   round(x["cobrado"], 2), round(x["saldo"], 2)])
    for col in "EFG":
        for c in md[col][1:]: c.number_format = '"$"#,##0.00'
    ct = wb.create_sheet("Contratos")
    ct.append(["Propiedad", "Unidad", "Inquilino", "Teléfono", "Correo", "Inicio", "Fin", "Alquiler", "Día de pago",
               "Depósito recibido", "Depósito a devolver", "Depósito devuelto", "Estado"])
    for c in db().execute("SELECT c.*, p.nombre pn FROM contratos c JOIN propiedades p ON p.id=c.propiedad_id ORDER BY p.nombre, c.inicio"):
        ct.append([c["pn"], c["unidad"], c["inquilino"], c["telefono"], c["correo"], c["inicio"], c["fin"], c["monto"],
                   c["dia_pago"], c["deposito_recibido"], c["deposito_devolver"], c["deposito_devuelto"], c["estado"]])
    for hoja in wb:
        for c in hoja[1]:
            c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="2E7D5B")
        for col in hoja.columns:
            hoja.column_dimensions[col[0].column_letter].width = 16
    for hoja, cols in ((ws, "FG"), (r, "BCDE")):
        for col in cols:
            for c in hoja[col][1:]: c.number_format = '"$"#,##0.00'
    fd, ruta = tempfile.mkstemp(suffix=".xlsx"); os.close(fd); wb.save(ruta)
    return send_file(ruta, as_attachment=True, download_name=f"mis-finanzas-{anio}.xlsx")


@app.route("/copia")
@requiere
def copia():
    fd, ruta = tempfile.mkstemp(suffix=".db"); os.close(fd)
    src, dst = sqlite3.connect(DB), sqlite3.connect(ruta)
    src.backup(dst); dst.close(); src.close()
    db().execute("INSERT INTO ajustes(clave, valor) VALUES('ultima_copia', ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                 (date.today().isoformat(),))
    anotar("Descargaste una copia de seguridad"); db().commit()
    return send_file(ruta, as_attachment=True, download_name=f"mis-finanzas-copia-{date.today().isoformat()}.db")


@app.route("/historial")
@requiere
def ver_historial():
    return render_template("historial.html",
                           filas=db().execute("SELECT * FROM historial ORDER BY id DESC LIMIT 300").fetchall())


def copias_diarias():
    carpeta = os.path.join(os.path.dirname(os.path.abspath(DB)), "copias")
    while True:
        try:
            os.makedirs(carpeta, exist_ok=True)
            hoy = os.path.join(carpeta, f"finanzas-{date.today().isoformat()}.db")
            if not os.path.exists(hoy):
                s, d = sqlite3.connect(DB), sqlite3.connect(hoy); s.backup(d); d.close(); s.close()
                for f in sorted(os.listdir(carpeta))[:-30]:
                    os.remove(os.path.join(carpeta, f))
        except Exception:
            pass
        time.sleep(6 * 3600)


# ---------- Bolsa: portafolio, acciones a seguir y noticias (datos de Finnhub) ----------
FINNHUB = "https://finnhub.io/api/v1"
RE_SIMBOLO = re.compile(r"^[A-Z][A-Z0-9.\-]{0,9}$")


def llave_finnhub():
    return os.environ.get("FINNHUB_KEY") or ajuste("finnhub_key") or ""


def finnhub(ruta, cache_seg, llave=None, **params):
    """Pide datos a Finnhub y los guarda un rato en la base para no gastar el límite gratis (60 por minuto)."""
    llave = llave or llave_finnhub()
    if not llave:
        return None
    from urllib.parse import urlencode
    clave = ruta + "?" + urlencode(sorted(params.items()))
    con = sqlite3.connect(DB, timeout=3)
    try:
        r = con.execute("SELECT datos, cuando FROM bolsa_cache WHERE clave=?", (clave,)).fetchone()
        if r and time.time() - r[1] < cache_seg:
            return json.loads(r[0])
        try:
            req = urllib.request.Request(f"{FINNHUB}{ruta}?{urlencode({**params, 'token': llave})}",
                                         headers={"User-Agent": "mis-finanzas"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                datos = json.loads(resp.read().decode())
        except Exception:
            return json.loads(r[0]) if r else None  # sin internet: lo último que se guardó
        try:
            con.execute("INSERT INTO bolsa_cache(clave, datos, cuando) VALUES(?,?,?) ON CONFLICT(clave) DO UPDATE "
                        "SET datos=excluded.datos, cuando=excluded.cuando", (clave, json.dumps(datos), time.time()))
            con.commit()
        except sqlite3.Error:
            pass  # la base está ocupada: se guarda la próxima vez
        return datos
    finally:
        con.close()


def cotizacion(sim, llave=None):
    q = finnhub("/quote", 180, llave, symbol=sim)
    return q if q and q.get("c") else None


def info_accion(sim, llave=None):
    p = finnhub("/stock/profile2", 7 * 86400, llave, symbol=sim) or {}
    m = (finnhub("/stock/metric", 12 * 3600, llave, symbol=sim, metric="all") or {}).get("metric") or {}
    return {"nombre": p.get("name") or sim, "logo": p.get("logo"), "industria": p.get("finnhubIndustry"),
            "web": p.get("weburl"), "alto52": m.get("52WeekHigh"), "bajo52": m.get("52WeekLow")}


def datos_varias(simbolos):
    """Precio + info de varias acciones a la vez."""
    from concurrent.futures import ThreadPoolExecutor
    simbolos = sorted(set(simbolos))
    llave = llave_finnhub()  # se lee aquí: los hilos no pueden leer la base de la página
    if not simbolos or not llave:
        return {s: {"q": None, "i": {"nombre": s}} for s in simbolos}
    with ThreadPoolExecutor(max_workers=6) as ex:
        qs = dict(zip(simbolos, ex.map(lambda s: cotizacion(s, llave), simbolos)))
        ins = dict(zip(simbolos, ex.map(lambda s: info_accion(s, llave), simbolos)))
    return {s: {"q": qs[s], "i": ins[s]} for s in simbolos}


def senales(q, i, pos=None):
    """Señales informativas, no consejos: qué pasó con el precio."""
    out = []
    if not q:
        return out
    c, dp = q.get("c") or 0, q.get("dp") or 0
    if dp <= -5:
        out.append(("baja", f"Cayó {abs(dp):.1f}% hoy"))
    elif dp >= 5:
        out.append(("sube", f"Subió {dp:.1f}% hoy"))
    if i.get("alto52") and c:
        desde = (c / i["alto52"] - 1) * 100
        if desde <= -20:
            out.append(("baja", f"Está {abs(desde):.0f}% por debajo de su máximo del año ({dinero(i['alto52'])})"))
    if i.get("bajo52") and c and c <= i["bajo52"] * 1.05:
        out.append(("baja", f"Cerca de su precio más bajo del año ({dinero(i['bajo52'])})"))
    if i.get("alto52") and c and c >= i["alto52"] * 0.97:
        out.append(("sube", "Cerca de su precio más alto del año"))
    if pos and pos["acciones"] > 0 and pos["costo"] > 0:
        g = (c * pos["acciones"] / pos["costo"] - 1) * 100
        if g <= -15:
            out.append(("baja", f"Tu posición va {abs(g):.0f}% abajo"))
        elif g >= 25:
            out.append(("sube", f"Tu posición va {g:.0f}% arriba"))
    return out


def posiciones():
    """Lo que tienes de cada acción, sacado de tus compras y ventas (costo promedio)."""
    res = {}
    for o in db().execute("SELECT * FROM bolsa_ops ORDER BY fecha, id"):
        p = res.setdefault(o["simbolo"], {"simbolo": o["simbolo"], "acciones": 0.0, "costo": 0.0, "realizado": 0.0,
                                          "invertido": 0.0, "ops": []})
        p["ops"].append(o)
        if o["tipo"] == "compra":
            p["acciones"] += o["acciones"]; p["costo"] += o["monto"]; p["invertido"] += o["monto"]
        else:
            prom = p["costo"] / p["acciones"] if p["acciones"] else 0
            vend = min(o["acciones"], p["acciones"])
            p["realizado"] += o["monto"] - prom * vend
            p["costo"] -= prom * vend; p["acciones"] -= vend
            if p["acciones"] < 1e-9:
                p["acciones"], p["costo"] = 0.0, 0.0
    return res


@app.route("/bolsa", methods=["GET", "POST"])
@requiere
def bolsa():
    if request.method == "POST":
        acc = request.form.get("accion")
        sim = request.form.get("simbolo", "").strip().upper().lstrip("$")
        if acc == "llave":
            k = request.form.get("llave", "").strip()
            if not k:
                db().execute("DELETE FROM ajustes WHERE clave='finnhub_key'"); flash("Llave quitada.")
            elif not re.fullmatch(r"[A-Za-z0-9]{10,60}", k):
                flash("Esa llave no se ve bien. Cópiala completa de finnhub.io (Dashboard → API Key).")
            else:
                ajuste("finnhub_key", k)
                db().execute("DELETE FROM bolsa_cache"); db().commit()
                flash("Llave guardada." if cotizacion("AAPL") else
                      "Llave guardada, pero no pude traer precios todavía. Revisa que esté bien copiada.")
        elif acc == "seguir":
            if not RE_SIMBOLO.match(sim):
                flash("Escribe el símbolo de la acción, por ejemplo AAPL o TSLA.")
            elif llave_finnhub() and not cotizacion(sim):
                flash(f"No encontré la acción «{sim}». Revisa el símbolo (búscalo en Google: «{sim} stock»).")
            else:
                db().execute("INSERT OR IGNORE INTO bolsa_seguir(simbolo, agregada) VALUES(?,?)", (sim, date.today().isoformat()))
                anotar(f"Bolsa: empezaste a seguir {sim}"); flash(f"Ahora sigues {sim}.")
        elif acc == "dejar":
            db().execute("DELETE FROM bolsa_seguir WHERE simbolo=?", (sim,)); flash(f"Ya no sigues {sim}.")
        elif acc == "operacion":
            tipo = "venta" if request.form.get("tipo") == "venta" else "compra"
            fe = request.form.get("fecha") or date.today().isoformat()
            monto, precio, acciones = num(request.form.get("monto")), num(request.form.get("precio")), num(request.form.get("acciones"))
            if not precio and llave_finnhub() and RE_SIMBOLO.match(sim):
                precio = (cotizacion(sim) or {}).get("c")
            if acciones and precio and not monto:
                monto = round(acciones * precio, 2)
            if monto and precio and not acciones:
                acciones = monto / precio
            if acciones and monto and not precio:
                precio = monto / acciones
            if not RE_SIMBOLO.match(sim) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fe):
                flash("Escribe el símbolo de la acción, por ejemplo AAPL.")
            elif not (monto and precio and acciones) or min(monto, precio, acciones) <= 0:
                flash("Pon cuánto dinero fue y a qué precio estaba la acción.")
            else:
                if tipo == "venta":
                    tiene = posiciones().get(sim, {}).get("acciones", 0)
                    if acciones > tiene + 1e-6:
                        flash(f"Solo tienes {tiene:.4f} acciones de {sim}.")
                        return redirect(url_for("bolsa_accion", sim=sim))
                db().execute("INSERT INTO bolsa_ops(simbolo, tipo, fecha, monto, precio, acciones, nota) VALUES(?,?,?,?,?,?,?)",
                             (sim, tipo, fe, round(monto, 2), precio, acciones, request.form.get("nota", "").strip()[:200]))
                db().execute("INSERT OR IGNORE INTO bolsa_seguir(simbolo, agregada) VALUES(?,?)", (sim, date.today().isoformat()))
                anotar(f"Bolsa: {'compraste' if tipo == 'compra' else 'vendiste'} {dinero(monto)} de {sim} a {dinero(precio)}")
                flash(f"Anotado: {'compraste' if tipo == 'compra' else 'vendiste'} {acciones:.4f} acciones de {sim} por {dinero(monto)}.")
        elif acc == "borrar_op":
            o = db().execute("SELECT * FROM bolsa_ops WHERE id=?", (request.form.get("oid", type=int),)).fetchone()
            if o:
                db().execute("DELETE FROM bolsa_ops WHERE id=?", (o["id"],))
                anotar(f"Bolsa: borraste una {o['tipo']} de {o['simbolo']} ({dinero(o['monto'])})"); flash("Operación borrada.")
        db().commit()
        volver = request.form.get("volver", "")
        return redirect(volver if volver.startswith("/bolsa") else url_for("bolsa"))
    pos = posiciones()
    seguir = [r["simbolo"] for r in db().execute("SELECT simbolo FROM bolsa_seguir ORDER BY simbolo")]
    datos = datos_varias(list(pos) + seguir)
    filas, tot = [], {"valor": 0.0, "costo": 0.0, "hoy": 0.0, "realizado": 0.0, "sin_precio": 0}
    for s, p in pos.items():
        tot["realizado"] += p["realizado"]
        if p["acciones"] <= 0:
            continue
        q = datos[s]["q"]
        precio = q["c"] if q else None
        valor = precio * p["acciones"] if precio else p["costo"]
        if not precio:
            tot["sin_precio"] += 1
        tot["valor"] += valor; tot["costo"] += p["costo"]
        if q and q.get("pc"):
            tot["hoy"] += (q["c"] - q["pc"]) * p["acciones"]
        filas.append({"s": s, "p": p, "q": q, "i": datos[s]["i"], "valor": valor, "ganancia": valor - p["costo"],
                      "pct": (valor / p["costo"] - 1) * 100 if p["costo"] else 0, "senales": senales(q, datos[s]["i"], p)})
    filas.sort(key=lambda x: -x["valor"])
    lista = [{"s": s, "q": datos[s]["q"], "i": datos[s]["i"], "tengo": s in pos and pos[s]["acciones"] > 0,
              "senales": senales(datos[s]["q"], datos[s]["i"])} for s in seguir]
    # primero las que tienen señales de baja (posibles oportunidades para revisar)
    lista.sort(key=lambda x: (not any(k == "baja" for k, _ in x["senales"]), x["s"]))
    return render_template("bolsa.html", filas=filas, lista=lista, tot=tot, hay_llave=bool(llave_finnhub()),
                           llave_env=bool(os.environ.get("FINNHUB_KEY")), hoy=date.today().isoformat(),
                           cerrados=[p for p in pos.values() if p["acciones"] <= 0])


@app.route("/bolsa/<sim>")
@requiere
def bolsa_accion(sim):
    sim = sim.upper()
    if not RE_SIMBOLO.match(sim):
        abort(404)
    q, i = cotizacion(sim), info_accion(sim) if llave_finnhub() else {"nombre": sim}
    p = posiciones().get(sim)
    hoy = date.today()
    noticias = finnhub("/company-news", 1800, symbol=sim, **{"from": (hoy - timedelta(days=10)).isoformat(),
                                                              "to": hoy.isoformat()}) or []
    noticias = [n for n in noticias if isinstance(n, dict) and n.get("headline") and str(n.get("url", "")).startswith("http")][:8]
    for n in noticias:
        n["fecha"] = datetime.fromtimestamp(n.get("datetime") or 0).date().isoformat() if n.get("datetime") else ""
    rango = None
    if q and i.get("alto52") and i.get("bajo52") and i["alto52"] > i["bajo52"]:
        rango = max(0, min(100, (q["c"] - i["bajo52"]) / (i["alto52"] - i["bajo52"]) * 100))
    return render_template("bolsa_accion.html", sim=sim, q=q, i=i, p=p, noticias=noticias, rango=rango,
                           senales=senales(q, i, p), sigo=db().execute("SELECT 1 FROM bolsa_seguir WHERE simbolo=?", (sim,)).fetchone(),
                           hay_llave=bool(llave_finnhub()), hoy=hoy.isoformat())


# ---------- Susus: grupos de ahorro por turnos ----------
MESES_CORTOS = {"ene": 1, "feb": 2, "mar": 3, "abr": 4, "may": 5, "jun": 6, "jul": 7, "ago": 8, "sep": 9, "set": 9,
                "oct": 10, "nov": 11, "dic": 12}
MIS_NOMBRES = re.compile(r"\b(cr?h?ist?[oó]ph?er|cristofer|cristopher)\b", re.I)


def leer_lista_susu(texto, hoy=None):
    """Lee la lista de turnos como viene de WhatsApp: '*3. Desiree 20 Oct* ✅' o '20 de octubre Mary Pagó'."""
    hoy = hoy or date.today()
    filas = []
    for linea in texto.splitlines():
        l = re.sub(r"[*_~✅✔️🤑💰🎉👍]", " ", linea).strip()
        if not l:
            continue
        m = re.search(r"\b(\d{1,2})\s*(?:de\s+)?([A-Za-zÁÉÍÓÚáéíóú]{3,})\.?", l)
        mes = MESES_CORTOS.get(m.group(2).lower()[:3].replace("é", "e")) if m else None
        if not m or not mes or not 1 <= int(m.group(1)) <= 31:
            continue
        nombre = (l[:m.start()] + " " + l[m.end():])
        nombre = re.sub(r"^\s*\d{1,2}\s*[.)-]\s*", "", nombre.strip())
        nombre = re.sub(r"\b(pag[oó]|cobra|cobr[oó]|de)\b\.?", " ", nombre, flags=re.I)
        nombre = re.sub(r"\s+", " ", nombre).strip(" .,-:") or "?"
        filas.append({"dia": int(m.group(1)), "mes": mes, "nombre": nombre[:60]})
    if not filas:
        return []
    # el año: la primera fecha es la más cercana a hoy hacia atrás (o hasta 3 meses adelante); luego va subiendo
    anio = hoy.year if filas[0]["mes"] <= hoy.month + 3 else hoy.year - 1
    out, previo = [], None
    for f in filas:
        if previo and (f["mes"], f["dia"]) < previo:
            anio += 1
        previo = (f["mes"], f["dia"])
        out.append({"fecha": fecha_en_mes(anio, f["mes"], f["dia"]), "nombre": f["nombre"],
                    "mio": bool(MIS_NOMBRES.search(f["nombre"]))})
    return out


def estado_susu(s):
    turnos = db().execute("SELECT * FROM susu_turnos WHERE susu_id=? ORDER BY fecha, id", (s["id"],)).fetchall()
    manos = db().execute("SELECT m.*, d.nombre deuda FROM susu_manos m LEFT JOIN deudas d ON d.id=m.deuda_id "
                         "WHERE m.susu_id=? ORDER BY m.id", (s["id"],)).fetchall()
    pagados = {r["turno_id"] for r in db().execute("SELECT DISTINCT turno_id FROM susu_pagos WHERE susu_id=?", (s["id"],))}
    previos = s["previos"] or 0
    hoy = date.today()
    rondas = []
    for k, t in enumerate(turnos):
        fe = date.fromisoformat(t["fecha"])
        cuota = [m for m in manos if not m["desde"] or m["desde"] <= t["fecha"]]
        pagada = t["id"] in pagados or k < previos
        rondas.append({"t": t, "n": k + 1, "fecha": fe, "manos": cuota, "total": sum(m["monto"] for m in cuota),
                       "pagada": pagada, "antes": k < previos and t["id"] not in pagados,
                       "estado": "pagada" if pagada else ("atrasada" if fe < hoy else ("hoy" if fe == hoy else "luego"))})
    mio = [r for r in rondas if r["t"]["mio"]]
    bote = (s["monto"] or 0) * len(turnos)
    propio_pagado = sum(1 for r in rondas if r["pagada"]) * (s["monto"] or 0)
    cobrado = sum(t["cobrado"] or 0 for t in turnos if t["mio"])
    prox = next((r for r in rondas if not r["pagada"]), None)
    return {"s": s, "turnos": turnos, "manos": manos, "rondas": rondas, "mio": mio, "bote": bote,
            "puesto": propio_pagado, "falta": max(0, bote - propio_pagado), "cobrado": cobrado,
            "neto": propio_pagado - cobrado, "prox": prox, "n_pagadas": sum(1 for r in rondas if r["pagada"])}


def susus_activos():
    return [estado_susu(s) for s in db().execute("SELECT * FROM susus WHERE activo=1 ORDER BY id")]


@app.route("/susu", methods=["GET", "POST"])
@requiere
def susu():
    if request.method == "POST":
        f = request.form
        monto = num(f.get("monto")) or 0
        turnos = leer_lista_susu(f.get("lista", ""))
        nombre = f.get("nombre", "").strip()[:60] or "Susu"
        if monto <= 0 or len(turnos) < 2:
            flash("Pon cuánto se da por mano y pega la lista de turnos con sus fechas (ej. «3. Desiree 20 Oct»).")
            return redirect(url_for("susu"))
        previos = max(0, min(len(turnos), f.get("previos", type=int) or 0))
        sid = db().execute("INSERT INTO susus(nombre, organizador, monto, previos, activo, creado) VALUES(?,?,?,?,1,?)",
                           (nombre, f.get("organizador", "").strip()[:60], monto, previos, date.today().isoformat())).lastrowid
        for t in turnos:
            db().execute("INSERT INTO susu_turnos(susu_id, fecha, nombre, mio) VALUES(?,?,?,?)",
                         (sid, t["fecha"].isoformat(), t["nombre"], 1 if t["mio"] else 0))
        db().execute("INSERT INTO susu_manos(susu_id, nombre, monto, propia) VALUES(?,?,?,1)", (sid, "Tu mano", monto))
        anotar(f"Creaste el susu {nombre}: {dinero(monto)} por mano, {len(turnos)} turnos")
        db().commit()
        mios = [t for t in turnos if t["mio"]]
        flash(f"Listo: {len(turnos)} turnos." + (f" Te toca cobrar el {fecha(mios[0]['fecha'])}." if mios
              else " No encontré tu nombre en la lista: toca tu turno abajo para marcarlo."))
        return redirect(url_for("ver_susu", sid=sid))
    lista = susus_activos()
    hoy = date.today()
    # lo que viene: los próximos pagos de todos los susus juntos, y los de este mes ya pagados (en verde)
    viene = []
    for e in lista:
        nom = e["s"]["nombre"]
        for r in e["rondas"]:
            este_mes = r["fecha"].year == hoy.year and r["fecha"].month == hoy.month
            if (not r["pagada"] and r["fecha"] <= hoy + timedelta(days=45)) or (r["pagada"] and not r["antes"] and este_mes):
                viene.append({"susu": e["s"], "nombre": nom, "r": r})
    viene.sort(key=lambda x: (x["r"]["fecha"], x["nombre"]))
    return render_template("susu.html", lista=lista, viene=viene, hoy=hoy, viejos=db().execute("SELECT * FROM susus WHERE activo=0 ORDER BY id DESC").fetchall())


@app.route("/susu/<int:sid>", methods=["GET", "POST"])
@requiere
def ver_susu(sid):
    s = db().execute("SELECT * FROM susus WHERE id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    if request.method == "POST":
        acc, f = request.form.get("accion"), request.form
        e = estado_susu(s)
        if acc == "pagar":
            r = next((x for x in e["rondas"] if x["t"]["id"] == f.get("tid", type=int)), None)
            if r and not r["pagada"]:
                hoy = date.today().isoformat()
                for m in r["manos"]:
                    if m["deuda_id"] and db().execute("SELECT 1 FROM deudas WHERE id=? AND activa=1", (m["deuda_id"],)).fetchone():
                        mid = db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota, deuda_id) VALUES('gasto',?,?,?,?,?)",
                                           (hoy, m["monto"], "Tarjetas y deudas", f"Abono {m['deuda']} (su mano del susu {s['nombre']})",
                                            m["deuda_id"])).lastrowid
                    else:
                        mid = db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota) VALUES('gasto',?,?,?,?)",
                                           (hoy, m["monto"], "Susu", f"Susu {s['nombre']} · turno {r['n']}" +
                                            ("" if m["propia"] else f" · mano de {m['nombre']}"))).lastrowid
                    db().execute("INSERT INTO susu_pagos(susu_id, turno_id, mano_id, monto, fecha, mov_id) VALUES(?,?,?,?,?,?)",
                                 (sid, r["t"]["id"], m["id"], m["monto"], hoy, mid))
                anotar(f"Susu {s['nombre']}: pagaste el turno {r['n']} ({dinero(r['total'])})")
                flash(f"Anotado: pagaste {dinero(r['total'])} del turno {r['n']}." +
                      (" Lo de " + ", ".join(m["nombre"] for m in r["manos"] if m["deuda_id"]) + " se le abonó a su deuda."
                       if any(m["deuda_id"] for m in r["manos"]) else ""))
        elif acc == "deshacer":
            tid = f.get("tid", type=int)
            for p in db().execute("SELECT * FROM susu_pagos WHERE susu_id=? AND turno_id=?", (sid, tid)).fetchall():
                if p["mov_id"]:
                    db().execute("DELETE FROM movimientos WHERE id=?", (p["mov_id"],))
            db().execute("DELETE FROM susu_pagos WHERE susu_id=? AND turno_id=?", (sid, tid))
            anotar(f"Susu {s['nombre']}: deshiciste un pago"); flash("Pago deshecho.")
        elif acc == "cobrar":
            t = db().execute("SELECT * FROM susu_turnos WHERE id=? AND susu_id=? AND mio=1", (f.get("tid", type=int), sid)).fetchone()
            m = num(f.get("monto_cobro")) or e["bote"]
            if t and not t["cobrado"]:
                mid = db().execute("INSERT INTO movimientos(tipo, fecha, monto, categoria, nota) VALUES('ingreso',?,?,?,?)",
                                   (date.today().isoformat(), m, "Susu", f"Cobré el susu {s['nombre']}")).lastrowid
                db().execute("UPDATE susu_turnos SET cobrado=?, mov_id=? WHERE id=?", (m, mid, t["id"]))
                anotar(f"Susu {s['nombre']}: cobraste {dinero(m)}"); flash(f"¡Cobraste {dinero(m)}! Quedó como ingreso de este mes.")
        elif acc == "mio":
            t = db().execute("SELECT * FROM susu_turnos WHERE id=? AND susu_id=?", (f.get("tid", type=int), sid)).fetchone()
            if t and not t["cobrado"]:
                db().execute("UPDATE susu_turnos SET mio=? WHERE id=?", (0 if t["mio"] else 1, t["id"]))
                flash("Listo." if t["mio"] else f"Marcado: el turno del {fecha(t['fecha'])} es tuyo.")
        elif acc == "mano":
            n = f.get("nombre_mano", "").strip()[:60]
            mm = num(f.get("monto_mano")) or s["monto"]
            did = f.get("deuda_mano", type=int)
            if n:
                db().execute("INSERT INTO susu_manos(susu_id, nombre, monto, deuda_id, desde, propia) VALUES(?,?,?,?,?,0)",
                             (sid, n, mm, did if did and db().execute("SELECT 1 FROM deudas WHERE id=?", (did,)).fetchone() else None,
                              f.get("desde_mano") or date.today().isoformat()))
                anotar(f"Susu {s['nombre']}: ahora también pagas la mano de {n} ({dinero(mm)})")
                flash(f"Listo: cada turno pagas también {dinero(mm)} de {n}.")
        elif acc == "quitar_mano":
            db().execute("DELETE FROM susu_manos WHERE id=? AND susu_id=? AND propia=0", (f.get("mid", type=int), sid))
            flash("Quitada.")
        elif acc == "editar":
            db().execute("UPDATE susus SET nombre=?, organizador=?, previos=? WHERE id=?",
                         (f.get("nombre", "").strip()[:60] or s["nombre"], f.get("organizador", "").strip()[:60],
                          max(0, f.get("previos", type=int) or 0), sid))
            flash("Guardado.")
        elif acc == "eliminar":
            for tabla in ("susu_pagos", "susu_manos", "susu_turnos"):
                db().execute(f"DELETE FROM {tabla} WHERE susu_id=?", (sid,))
            db().execute("DELETE FROM susus WHERE id=?", (sid,))
            anotar(f"Eliminaste el susu {s['nombre']}"); db().commit()
            flash(f"Susu {s['nombre']} eliminado. Lo que pagaste y cobraste se queda en tus meses."); return redirect(url_for("susu"))
        elif acc == "terminar":
            db().execute("UPDATE susus SET activo=0 WHERE id=?", (sid,))
            anotar(f"Terminaste el susu {s['nombre']}"); db().commit()
            flash("Susu archivado."); return redirect(url_for("susu"))
        db().commit()
        volver = request.form.get("volver", "")
        return redirect(volver if volver.startswith("/susu") else url_for("ver_susu", sid=sid) + (f"#t{f.get('tid')}" if f.get("tid") else ""))
    deudas = [x for x in estado_deudas() if x["saldo"] > 0]
    return render_template("susu_ver.html", e=estado_susu(s), deudas=deudas, hoy=date.today())


# ---------- Seguros de vida con valor (IUL, whole life) ----------
def estado_poliza(p):
    vals = db().execute("SELECT * FROM poliza_valores WHERE poliza_id=? ORDER BY fecha, id", (p["id"],)).fetchall()
    u = vals[-1] if vals else None
    rescate = (u["rescate"] or 0) if u else 0
    pagado = (u["pagado"] or 0) if u else 0
    return {"p": p, "vals": vals, "u": u, "rescate": rescate, "acumulado": (u["acumulado"] or 0) if u else 0,
            "pagado": pagado, "dif": rescate - pagado, "dias_sin": (date.today() - date.fromisoformat(u["fecha"])).days if u else None}


def polizas_activas():
    return [estado_poliza(p) for p in db().execute("SELECT * FROM polizas WHERE activa=1 ORDER BY id")]


def linea_valores(vals, campo, ancho=300, alto=70, tope=None):
    pts = [v[campo] or 0 for v in vals]
    if len(pts) < 2:
        return ""
    tope = tope or max(pts) or 1
    paso = ancho / (len(pts) - 1)
    return " ".join(f"{'M' if i == 0 else 'L'}{i * paso:.1f},{alto - (y / tope) * (alto - 6) - 3:.1f}" for i, y in enumerate(pts))


@app.route("/seguros", methods=["GET", "POST"])
@requiere
def seguros():
    if request.method == "POST":
        f = request.form
        nombre = f.get("nombre", "").strip()[:60]
        prima = num(f.get("prima")) or 0
        dia = max(1, min(31, f.get("dia", type=int) or 1))
        if not nombre:
            flash("Ponle un nombre al seguro.")
            return redirect(url_for("seguros"))
        fijo_id = None
        if f.get("crear_fijo") and prima > 0:
            fijo_id = db().execute("INSERT INTO fijos(tipo, nombre, categoria, monto, dias, cada, desde) VALUES('gasto',?,?,?,?,1,?)",
                                   (nombre, "Seguros", prima, str(dia), date.today().isoformat())).lastrowid
        pid = db().execute("INSERT INTO polizas(nombre, aseguradora, tipo, prima, dia_pago, beneficio, notas, fijo_id, activa, creada) "
                           "VALUES(?,?,?,?,?,?,?,?,1,?)",
                           (nombre, f.get("aseguradora", "").strip()[:60], f.get("tipo", "").strip()[:60], prima, dia,
                            num(f.get("beneficio")), f.get("notas", "").strip()[:300], fijo_id, date.today().isoformat())).lastrowid
        if any(num(f.get(k)) for k in ("acumulado", "rescate", "pagado")):
            db().execute("INSERT INTO poliza_valores(poliza_id, fecha, acumulado, rescate, pagado) VALUES(?,?,?,?,?)",
                         (pid, date.today().isoformat(), num(f.get("acumulado")), num(f.get("rescate")), num(f.get("pagado"))))
        anotar(f"Agregaste el seguro {nombre}"); db().commit()
        flash(f"Listo: {nombre} agregado." + (" Su pago de cada mes ya sale en tus gastos fijos." if fijo_id else ""))
        return redirect(url_for("ver_seguro", pid=pid))
    return render_template("seguros.html", lista=polizas_activas(), hoy=date.today())


@app.route("/seguros/<int:pid>", methods=["GET", "POST"])
@requiere
def ver_seguro(pid):
    p = db().execute("SELECT * FROM polizas WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    if request.method == "POST":
        acc, f = request.form.get("accion"), request.form
        if acc == "valores":
            fe = f.get("fecha") if re.fullmatch(r"\d{4}-\d{2}-\d{2}", f.get("fecha", "")) else date.today().isoformat()
            a, r, pg = num(f.get("acumulado")), num(f.get("rescate")), num(f.get("pagado"))
            if a is None and r is None and pg is None:
                flash("Pon al menos el valor de rescate (Surrender Value).")
            else:
                db().execute("INSERT INTO poliza_valores(poliza_id, fecha, acumulado, rescate, pagado) VALUES(?,?,?,?,?)", (pid, fe, a, r, pg))
                if num(f.get("beneficio")):
                    db().execute("UPDATE polizas SET beneficio=? WHERE id=?", (num(f.get("beneficio")), pid))
                anotar(f"Seguro {p['nombre']}: actualizaste valores (rescate {dinero(r or 0)})")
                flash("Valores guardados.")
        elif acc == "borrar_valor":
            db().execute("DELETE FROM poliza_valores WHERE id=? AND poliza_id=?", (f.get("vid", type=int), pid)); flash("Borrado.")
        elif acc == "editar":
            prima = num(f.get("prima")) or 0
            dia = max(1, min(31, f.get("dia", type=int) or 1))
            db().execute("UPDATE polizas SET nombre=?, aseguradora=?, tipo=?, prima=?, dia_pago=?, beneficio=?, notas=? WHERE id=?",
                         (f.get("nombre", "").strip()[:60] or p["nombre"], f.get("aseguradora", "").strip()[:60], f.get("tipo", "").strip()[:60],
                          prima, dia, num(f.get("beneficio")), f.get("notas", "").strip()[:300], pid))
            if p["fijo_id"]:
                db().execute("UPDATE fijos SET monto=?, dias=? WHERE id=?", (prima, str(dia), p["fijo_id"]))
            flash("Guardado.")
        elif acc == "quitar":
            db().execute("UPDATE polizas SET activa=0 WHERE id=?", (pid,))
            if p["fijo_id"]:
                db().execute("UPDATE fijos SET activo=0 WHERE id=?", (p["fijo_id"],))
            anotar(f"Quitaste el seguro {p['nombre']}"); db().commit()
            flash("Seguro quitado. Sus pagos viejos se quedan en tus meses."); return redirect(url_for("seguros"))
        db().commit()
        return redirect(url_for("ver_seguro", pid=pid))
    e = estado_poliza(p)
    tope = max([max(v["acumulado"] or 0, v["rescate"] or 0, v["pagado"] or 0) for v in e["vals"]] or [1]) or 1
    lineas = {k: linea_valores(e["vals"], k, tope=tope) for k in ("acumulado", "rescate", "pagado")}
    return render_template("seguro_ver.html", e=e, lineas=lineas, hoy=date.today())


@app.template_filter("dinero")
def dinero(x):
    x = x or 0
    return ("-" if x < 0 else "") + "${:,.2f}".format(abs(x))


@app.template_filter("dinero0")
def dinero0(x):
    x = x or 0
    return ("-" if x < 0 else "") + "${:,.0f}".format(abs(x))


@app.template_filter("fecha_larga")
def fecha_larga(s):
    if not s: return ""
    d = s if isinstance(s, date) else date.fromisoformat(str(s)[:10])
    return f"{d.day} {MESES[d.month-1][:3]} {d.year}"


@app.template_filter("fecha")
def fecha(s):
    if not s: return ""
    d = s if isinstance(s, date) else date.fromisoformat(str(s)[:10])
    return f"{['lun','mar','mié','jue','vie','sáb','dom'][d.weekday()]} {d.day} {MESES[d.month-1][:3]}"


@app.context_processor
def comunes():
    ult = None
    if session.get("ok"):
        try:
            r = db().execute("SELECT valor FROM ajustes WHERE clave='ultima_copia'").fetchone()
            ult = r[0] if r else None
        except Exception:
            pass
    vieja = session.get("ok") and (not ult or (date.today() - date.fromisoformat(ult)).days >= 30)
    return {"copia_vieja": vieja, "nombre": NOMBRE, "con_enlace": CON_ENLACE}


iniciar_db()
threading.Thread(target=copias_diarias, daemon=True).start()
if CON_ENLACE and not os.environ.get("SIN_SYNC"):
    threading.Thread(target=sync_en_fondo, daemon=True).start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
